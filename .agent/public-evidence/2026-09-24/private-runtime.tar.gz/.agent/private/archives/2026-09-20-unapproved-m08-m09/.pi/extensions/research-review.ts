import { Type } from "@earendil-works/pi-ai";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { ReviewDeliveryCore } from "../../src/review-delivery/core.ts";
import { createPiReviewExecutor } from "../../src/review-delivery/pi.ts";
import type {
	M08PrepareInput,
	M08ReviewInput,
	M09FinalizeInput,
	M09PrepareInput,
	M09ReproduceInput,
} from "../../src/review-delivery/types.ts";

const textResult = (value: unknown, terminate = false) => ({
	content: [{ type: "text" as const, text: JSON.stringify(value, null, 2) }],
	details: value,
	...(terminate ? { terminate: true } : {}),
});

export const finalizeReceipt = (result: Awaited<ReturnType<ReviewDeliveryCore["m09Finalize"]>>) => {
	const running = result.runningTasks.filter((task) => task.status !== "stopped");
	const lines = [
		`本轮当前目标已完成本地收口（${result.status}）。`,
		`交付目录：${result.deliveryDir}`,
		`研究状态：${result.researchStatus}`,
		`实际核验状态：${result.verification.status}；声明范围：${result.verification.declaredScope}`,
		`未决事项：${result.unresolved.length ? result.unresolved.join("；") : "无另行登记"}`,
		`仍运行或状态未知的任务：${running.length ? running.map((task) => `${task.id}(${task.status})`).join("；") : "无"}`,
		`恢复入口：${result.resumeEntry}`,
		"未发布、未发送，也未启动下一研究目标。此回执仅请求结束当前 agent turn，不关闭 Pi 会话或进程。",
	];
	return { content: [{ type: "text" as const, text: lines.join("\n") }], details: result, terminate: true };
};

const stringArray = () => Type.Array(Type.String());

export default function researchReviewExtension(pi: ExtensionAPI): void {
	pi.registerTool({
		name: "m08_prepare",
		label: "M08 prepare",
		description: "Freeze selected workspace-relative materials for M08 review. Does not run a model or declare scientific validity.",
		parameters: Type.Object({
			goal: Type.String(),
			scope: Type.String(),
			claims: stringArray(),
			versionLabel: Type.String(),
			originalProblemPath: Type.String(),
			materials: Type.Array(Type.Object({ path: Type.String(), purpose: Type.String(), limitations: Type.Optional(stringArray()) })),
		}),
		async execute(_id, params, signal, _update, ctx) {
			if (signal?.aborted) throw new Error("m08_prepare aborted");
			const core = new ReviewDeliveryCore({ workspaceRoot: ctx.cwd });
			return textResult(await core.m08Prepare(params as M08PrepareInput));
		},
	});

	pi.registerTool({
		name: "m08_review",
		label: "M08 review",
		description: "Run explicitly configured independent Pi SDK reviewers over the frozen M08 snapshot. Incurs model usage.",
		parameters: Type.Object({
			reviewId: Type.String(),
			selfReview: Type.Object({
				reportPath: Type.String(),
				summary: Type.String(),
				readCoverageDeclared: stringArray(),
				limitations: stringArray(),
			}),
			reviewers: Type.Array(Type.String({ description: "Explicit provider/model or provider/model:thinking" })),
		}),
		async execute(_id, params, signal, _update, ctx) {
			if (signal?.aborted) throw new Error("m08_review aborted");
			const core = new ReviewDeliveryCore({
				workspaceRoot: ctx.cwd,
				reviewExecutor: createPiReviewExecutor({ signal }),
			});
			return textResult(await core.m08Review(params as M08ReviewInput));
		},
	});

	pi.registerTool({
		name: "m09_prepare",
		label: "M09 prepare",
		description: "Prepare a local, purpose-specific delivery from the reviewed version and an explicit M04 record. Does not publish or send.",
		parameters: Type.Object({
			reviewId: Type.String(),
			versionLabel: Type.String(),
			m04: Type.Object({
				reviewId: Type.String(),
				versionLabel: Type.String(),
				recordPath: Type.String(),
				summary: Type.String(),
				requiresNewReview: Type.Boolean(),
			}),
			recipient: Type.String(),
			purpose: Type.String(),
			deliverableScope: Type.String(),
			explanation: Type.String(),
			selectedMaterials: stringArray(),
			omittedMaterialReasons: Type.Record(Type.String(), Type.String()),
			limitations: stringArray(),
			unresolved: stringArray(),
		}),
		async execute(_id, params, signal, _update, ctx) {
			if (signal?.aborted) throw new Error("m09_prepare aborted");
			const core = new ReviewDeliveryCore({ workspaceRoot: ctx.cwd });
			return textResult(await core.m09Prepare(params as M09PrepareInput));
		},
	});

	pi.registerTool({
		name: "m09_reproduce",
		label: "M09 reproduce",
		description: "Run an explicitly supplied command in a temporary copy and record actual execution. A successful exit does not prove a scientific claim.",
		parameters: Type.Object({
			deliveryId: Type.String(),
			kind: Type.Union([Type.Literal("redraw"), Type.Literal("analysis_rerun"), Type.Literal("full_recalculation")]),
			argv: stringArray(),
			cwd: Type.Optional(Type.String()),
			timeoutMs: Type.Number(),
			comparison: Type.Optional(Type.Object({ argv: stringArray(), cwd: Type.Optional(Type.String()), method: Type.String(), timeoutMs: Type.Number() })),
		}),
		async execute(_id, params, signal, _update, ctx) {
			if (signal?.aborted) throw new Error("m09_reproduce aborted");
			const core = new ReviewDeliveryCore({ workspaceRoot: ctx.cwd });
			return textResult(await core.m09Reproduce({ ...(params as M09ReproduceInput), signal }));
		},
	});

	pi.registerTool({
		name: "m09_finalize",
		label: "M09 finalize",
		description: "Close this local delivery stage and request that the current turn end. Does not stop Pi, publish, send, or start a new target.",
		parameters: Type.Object({
			deliveryId: Type.String(),
			researchStatus: Type.String(),
			declaredVerificationScope: Type.String(),
			unresolved: stringArray(),
			resumeEntry: Type.String(),
			runningTasks: Type.Array(Type.Object({
				id: Type.String(),
				description: Type.String(),
				status: Type.Union([Type.Literal("running"), Type.Literal("unknown"), Type.Literal("stopped")]),
			})),
		}),
		async execute(_id, params, signal, _update, ctx) {
			if (signal?.aborted) throw new Error("m09_finalize aborted");
			const core = new ReviewDeliveryCore({ workspaceRoot: ctx.cwd });
			return finalizeReceipt(await core.m09Finalize(params as M09FinalizeInput));
		},
	});
}

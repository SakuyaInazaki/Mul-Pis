import { spawn } from "node:child_process";
import { constants } from "node:fs";
import { access, cp, lstat, mkdir, mkdtemp, readFile, readdir, realpath, rename, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";
import type {
	CommandRecord,
	ComparisonSpec,
	CoreOptions,
	M08PrepareInput,
	M08PrepareResult,
	M08ReviewInput,
	M08ReviewResult,
	M09FinalizeInput,
	M09FinalizeResult,
	M09PrepareInput,
	M09PrepareResult,
	M09ReproduceInput,
	M09ReproduceResult,
	ReviewExecutor,
	ReviewerRecord,
	SnapshotMaterial,
	StoredSelfReview,
} from "./types.js";

type ReviewState = M08PrepareResult & {
	goal: string;
	scope: string;
	claims: string[];
	selfReview?: StoredSelfReview;
	reviewers: ReviewerRecord[];
	reviewerRoster?: string[];
	reviewStatus: "prepared" | "reviewing" | "awaiting_m04";
};

type DeliveryState = M09PrepareResult & {
	closed: boolean;
	reproductions: M09ReproduceResult[];
	final?: M09FinalizeResult;
};

const requireText = (value: string, label: string): string => {
	const normalized = value.trim();
	if (!normalized) throw new Error(`${label} must not be empty`);
	return normalized;
};

const requireNonEmpty = <T>(items: T[], label: string): T[] => {
	if (items.length === 0) throw new Error(`${label} must not be empty`);
	return items;
};

const isInside = (parent: string, child: string): boolean => child === parent || child.startsWith(`${parent}${path.sep}`);
const activeOperations = new Set<string>();
const MAX_CAPTURE_BYTES = 1_000_000;

export class ReviewDeliveryCore {
	readonly workspaceRoot: string;
	readonly runsRoot: string;
	readonly reviewExecutor?: ReviewExecutor;

	constructor(options: CoreOptions) {
		this.workspaceRoot = path.resolve(options.workspaceRoot);
		this.runsRoot = path.resolve(options.runsRoot ?? path.join(this.workspaceRoot, ".agent", "private", "review-delivery"));
		this.reviewExecutor = options.reviewExecutor;
	}

	async m08Prepare(input: M08PrepareInput): Promise<M08PrepareResult> {
		const goal = requireText(input.goal, "goal");
		const scope = requireText(input.scope, "scope");
		const versionLabel = requireText(input.versionLabel, "versionLabel");
		requireNonEmpty(input.claims, "claims");
		requireNonEmpty(input.materials, "materials");
		await mkdir(this.runsRoot, { recursive: true });
		const reviewId = `review-${randomUUID()}`;
		const temporaryDir = await mkdtemp(path.join(this.runsRoot, ".prepare-"));
		const finalDir = path.join(this.runsRoot, reviewId);
		try {
			const snapshotDir = path.join(temporaryDir, "snapshot");
			await mkdir(snapshotDir);
			const materials: SnapshotMaterial[] = [];
			for (const material of input.materials) {
				const relative = await this.resolveWorkspaceFile(material.path);
				const source = path.join(this.workspaceRoot, relative);
				const before = await lstat(source);
				const destination = path.join(snapshotDir, relative);
				await mkdir(path.dirname(destination), { recursive: true });
				await cp(source, destination, { force: false });
				const after = await lstat(source);
				if (before.size !== after.size || before.mtimeMs !== after.mtimeMs) {
					throw new Error(`material changed while snapshotting: ${relative}`);
				}
				materials.push({
					path: relative,
					purpose: requireText(material.purpose, `purpose for ${relative}`),
					limitations: material.limitations ?? [],
					snapshotPath: relative,
					size: before.size,
					mtimeMs: before.mtimeMs,
				});
			}
			const originalProblemPath = this.normalizeRelative(input.originalProblemPath, "originalProblemPath");
			if (!materials.some((material) => material.path === originalProblemPath)) {
				throw new Error("originalProblemPath must be included in the frozen materials snapshot");
			}
			const result: M08PrepareResult = {
				reviewId,
				status: "prepared",
				versionLabel,
				originalProblemPath,
				snapshotDir: path.join(finalDir, "snapshot"),
				materials,
			};
			const state: ReviewState = {
				...result,
				goal,
				scope,
				claims: input.claims.map((claim) => requireText(claim, "claim")),
				reviewers: [],
				reviewStatus: "prepared",
			};
			await writeFile(path.join(temporaryDir, "review.json"), JSON.stringify(state, null, 2));
			await rename(temporaryDir, finalDir);
			return result;
		} catch (error) {
			await rm(temporaryDir, { recursive: true, force: true });
			throw error;
		}
	}

	async m08Review(input: M08ReviewInput): Promise<M08ReviewResult> {
		return this.exclusive(`review:${input.reviewId}`, async () => {
		const state = await this.loadReview(input.reviewId);
		if (!this.reviewExecutor) throw new Error("reviewExecutor is required for m08_review");
		requireText(input.selfReview.summary, "selfReview.summary");
		requireNonEmpty(input.selfReview.readCoverageDeclared, "selfReview.readCoverageDeclared");
		const normalizedSelfReviewInput = {
			...input.selfReview,
			reportPath: this.normalizeRelative(input.selfReview.reportPath, "selfReview.reportPath"),
		};
		const reviewers = [...new Set(requireNonEmpty(input.reviewers, "reviewers").map((reviewer) => requireText(reviewer, "reviewer")))];
		reviewers.sort();
		if (state.reviewerRoster && JSON.stringify(state.reviewerRoster) !== JSON.stringify(reviewers)) {
			throw new Error("reviewer roster is frozen for this review run");
		}
		let storedSelfReview = state.selfReview;
		if (storedSelfReview) {
			const comparable = {
				reportPath: storedSelfReview.reportPath,
				summary: storedSelfReview.summary,
				readCoverageDeclared: storedSelfReview.readCoverageDeclared,
				limitations: storedSelfReview.limitations,
			};
			if (JSON.stringify(comparable) !== JSON.stringify(normalizedSelfReviewInput)) {
				throw new Error("self-review evidence is frozen for this review run");
			}
		} else {
			const selfReviewRelative = await this.resolveWorkspaceFile(normalizedSelfReviewInput.reportPath);
			const source = path.join(this.workspaceRoot, selfReviewRelative);
			const evidence = await lstat(source);
			const preservedSelfReview = path.join(this.runsRoot, state.reviewId, "records", `self-review${path.extname(selfReviewRelative)}`);
			await mkdir(path.dirname(preservedSelfReview), { recursive: true });
			await cp(source, preservedSelfReview, { force: false });
			storedSelfReview = {
				...normalizedSelfReviewInput,
				reportPath: selfReviewRelative,
				preservedReportPath: preservedSelfReview,
				evidenceSize: evidence.size,
				evidenceMtimeMs: evidence.mtimeMs,
			};
			state.selfReview = storedSelfReview;
			state.reviewerRoster = reviewers;
			await this.saveReview(state);
		}
		const previous = new Map(state.reviewers.map((record) => [record.reviewer, record]));
		const records: ReviewerRecord[] = [];
		for (const reviewer of reviewers) {
			const existing = previous.get(reviewer);
			if (existing?.status === "succeeded") {
				records.push(existing);
				continue;
			}
			try {
				const result = await this.reviewExecutor({
					reviewer,
					originalProblemPath: state.originalProblemPath,
					goal: state.goal,
					scope: state.scope,
					claims: state.claims,
					versionLabel: state.versionLabel,
					snapshotDir: state.snapshotDir,
					materials: state.materials,
				});
				records.push({ reviewer, status: "succeeded", result });
			} catch (error) {
				records.push({ reviewer, status: "failed", error: error instanceof Error ? error.message : String(error) });
			}
			state.reviewers = records;
			state.reviewStatus = "reviewing";
			await this.saveReview(state);
		}
		const allReviewersSucceeded = records.every((record) => record.status === "succeeded");
		state.reviewers = records;
		state.reviewStatus = allReviewersSucceeded ? "awaiting_m04" : "reviewing";
		await this.saveReview(state);
		return {
			reviewId: state.reviewId,
			status: state.reviewStatus,
			versionLabel: state.versionLabel,
			selfReview: storedSelfReview,
			reviewers: records,
			allReviewersSucceeded,
			sciencePassDeclared: false,
		};
		});
	}

	async m09Prepare(input: M09PrepareInput): Promise<M09PrepareResult> {
		const review = await this.loadReview(input.reviewId);
		if (review.reviewStatus !== "awaiting_m04") throw new Error("m08 review is not complete");
		if (input.versionLabel !== review.versionLabel || input.m04.versionLabel !== review.versionLabel) {
			throw new Error("M04 record and delivery must match the reviewed versionLabel");
		}
		if (input.m04.reviewId !== review.reviewId) throw new Error("M04 record must match reviewId");
		if (input.m04.requiresNewReview) throw new Error("M04 record requires a new M08 review");
		requireText(input.m04.summary, "m04.summary");
		const selected = [...new Set(requireNonEmpty(input.selectedMaterials, "selectedMaterials"))];
		const byPath = new Map(review.materials.map((material) => [material.path, material]));
		const selectedMaterials = selected.map((item) => {
			const normalized = this.normalizeRelative(item, "selected material");
			const material = byPath.get(normalized);
			if (!material) throw new Error(`selected material was not in the frozen review snapshot: ${normalized}`);
			return material;
		});
		const omittedMaterials = review.materials
			.filter((material) => !selectedMaterials.some((selectedMaterial) => selectedMaterial.path === material.path))
			.map((material) => ({
				material,
				reason: requireText(input.omittedMaterialReasons[material.path] ?? "", `omission reason for ${material.path}`),
			}));
		const m04Relative = await this.resolveWorkspaceFile(input.m04.recordPath);
		const deliveryId = `delivery-${randomUUID()}`;
		const reviewDir = path.join(this.runsRoot, review.reviewId);
		const temporaryDir = await mkdtemp(path.join(reviewDir, ".delivery-"));
		const finalDir = path.join(reviewDir, deliveryId);
		try {
			const contentDir = path.join(temporaryDir, "content");
			for (const material of selectedMaterials) {
				const source = path.join(review.snapshotDir, material.snapshotPath);
				const destination = path.join(contentDir, material.snapshotPath);
				await mkdir(path.dirname(destination), { recursive: true });
				await cp(source, destination, { force: false });
			}
			const preservedM04 = path.join(temporaryDir, "records", `m04-record${path.extname(m04Relative)}`);
			await mkdir(path.dirname(preservedM04), { recursive: true });
			await cp(path.join(this.workspaceRoot, m04Relative), preservedM04, { force: false });
			if (!review.selfReview) throw new Error("stored self-review evidence is missing");
			const selfReviewRecord = path.join("records", `self-review${path.extname(review.selfReview.reportPath)}`);
			await cp(review.selfReview.preservedReportPath, path.join(temporaryDir, selfReviewRecord), { force: false });
			const reviewRecords: M09PrepareResult["manifest"]["reviewRecords"] = [{ kind: "self", path: selfReviewRecord }];
			for (const [index, reviewer] of review.reviewers.entries()) {
				if (reviewer.status !== "succeeded" || !reviewer.result) throw new Error("external review evidence is incomplete");
				const recordPath = path.join("records", `external-review-${index + 1}.md`);
				await writeFile(path.join(temporaryDir, recordPath), reviewer.result.rawReport);
				reviewRecords.push({ kind: "external", reviewer: reviewer.reviewer, path: recordPath });
			}
			const manifest = {
				recipient: requireText(input.recipient, "recipient"),
				purpose: requireText(input.purpose, "purpose"),
				deliverableScope: requireText(input.deliverableScope, "deliverableScope"),
				explanation: requireText(input.explanation, "explanation"),
				m04Record: { ...input.m04, recordPath: m04Relative, preservedRecordPath: path.join("records", path.basename(preservedM04)) },
				reviewRecords,
				materials: selectedMaterials,
				limitations: input.limitations,
				unresolved: input.unresolved,
				omittedMaterials,
			};
			const result: M09PrepareResult = {
				deliveryId,
				status: "prepared",
				published: false,
				sent: false,
				reviewId: review.reviewId,
				versionLabel: review.versionLabel,
				deliveryDir: finalDir,
				deliveryDocumentPath: path.join(finalDir, "DELIVERY.md"),
				portableManifestPath: path.join(finalDir, "manifest.json"),
				manifest,
			};
			const state: DeliveryState = { ...result, closed: false, reproductions: [] };
			await writeFile(path.join(temporaryDir, "delivery.json"), JSON.stringify(state, null, 2));
			await this.writePortableFiles(state, temporaryDir);
			await rename(temporaryDir, finalDir);
			return result;
		} catch (error) {
			await rm(temporaryDir, { recursive: true, force: true });
			throw error;
		}
	}

	async m09Reproduce(input: M09ReproduceInput): Promise<M09ReproduceResult> {
		return this.exclusive(`delivery:${input.deliveryId}`, async () => {
		const state = await this.loadDelivery(input.deliveryId);
		this.assertOpen(state);
		requireNonEmpty(input.argv, "argv");
		if (!Number.isFinite(input.timeoutMs) || input.timeoutMs <= 0) throw new Error("timeoutMs must be positive");
		const workingCopy = await mkdtemp(path.join(tmpdir(), "review-delivery-"));
		await cp(path.join(state.deliveryDir, "content"), workingCopy, { recursive: true });
		const command = await this.runCommand(workingCopy, input.argv, input.cwd, input.timeoutMs, input.signal);
		let comparison: M09ReproduceResult["comparison"];
		if (input.comparison) {
			const record = await this.runComparison(workingCopy, input.comparison, input.signal);
			comparison = { ...record, method: requireText(input.comparison.method, "comparison.method") };
		}
		const result: M09ReproduceResult = {
			deliveryId: state.deliveryId,
			status: "verification_recorded",
			kind: input.kind,
			environment: { node: process.version, platform: process.platform, arch: process.arch },
			workingCopy,
			sandboxed: false,
			command,
			comparison,
			claimVerified: false,
		};
		state.reproductions.push(result);
		await this.saveDelivery(state);
		await this.writePortableFiles(state);
		return result;
		});
	}

	async m09Finalize(input: M09FinalizeInput): Promise<M09FinalizeResult> {
		return this.exclusive(`delivery:${input.deliveryId}`, async () => {
		const state = await this.loadDelivery(input.deliveryId);
		this.assertOpen(state);
		const unresolved = [...new Set([...state.manifest.unresolved, ...input.unresolved])];
		const result: M09FinalizeResult = {
			deliveryId: state.deliveryId,
			deliveryDir: state.deliveryDir,
			closed: true,
			stopRequested: true,
			status: "closed_local",
			published: false,
			sent: false,
			researchStatus: requireText(input.researchStatus, "researchStatus"),
			verification: {
				declaredScope: requireText(input.declaredVerificationScope, "declaredVerificationScope"),
				status: state.reproductions.length === 0 ? "not_run" : "recorded",
				results: state.reproductions,
			},
			unresolved,
			resumeEntry: requireText(input.resumeEntry, "resumeEntry"),
			runningTasks: input.runningTasks,
			declaredTasksAllStopped: input.runningTasks.length > 0 && input.runningTasks.every((task) => task.status === "stopped"),
		};
		state.closed = true;
		state.final = result;
		await this.saveDelivery(state);
		await this.writePortableFiles(state);
		return result;
		});
	}

	private async exclusive<T>(key: string, operation: () => Promise<T>): Promise<T> {
		const sharedKey = `${this.runsRoot}:${key}`;
		if (activeOperations.has(sharedKey)) throw new Error(`operation already active for ${key}`);
		activeOperations.add(sharedKey);
		try {
			return await operation();
		} finally {
			activeOperations.delete(sharedKey);
		}
	}

	private normalizeRelative(value: string, label: string): string {
		const normalized = path.normalize(requireText(value, label));
		if (path.isAbsolute(normalized) || normalized === ".." || normalized.startsWith(`..${path.sep}`)) {
			throw new Error(`${label} must stay within its root`);
		}
		return normalized;
	}

	private async resolveWorkspaceFile(value: string): Promise<string> {
		const relative = this.normalizeRelative(value, "material path");
		const candidate = path.join(this.workspaceRoot, relative);
		const stat = await lstat(candidate);
		if (!stat.isFile() || stat.isSymbolicLink()) throw new Error(`material must be a regular non-symlink file: ${relative}`);
		const [workspaceReal, candidateReal] = await Promise.all([realpath(this.workspaceRoot), realpath(candidate)]);
		if (!isInside(workspaceReal, candidateReal)) throw new Error(`material escapes workspace: ${relative}`);
		return relative;
	}

	private reviewFile(reviewId: string): string {
		return path.join(this.runsRoot, this.normalizeRelative(reviewId, "reviewId"), "review.json");
	}

	private async loadReview(reviewId: string): Promise<ReviewState> {
		return JSON.parse(await readFile(this.reviewFile(reviewId), "utf8")) as ReviewState;
	}

	private async saveReview(state: ReviewState): Promise<void> {
		await writeFile(this.reviewFile(state.reviewId), JSON.stringify(state, null, 2));
	}

	private async findDeliveryFile(deliveryId: string): Promise<string> {
		const normalized = this.normalizeRelative(deliveryId, "deliveryId");
		const entries = await readdir(this.runsRoot, { withFileTypes: true });
		for (const entry of entries) {
			if (!entry.isDirectory() || !entry.name.startsWith("review-")) continue;
			const candidate = path.join(this.runsRoot, entry.name, normalized, "delivery.json");
			try {
				await access(candidate, constants.R_OK);
				return candidate;
			} catch {
				// Continue looking in other review runs.
			}
		}
		throw new Error(`delivery not found: ${deliveryId}`);
	}

	private async loadDelivery(deliveryId: string): Promise<DeliveryState> {
		return JSON.parse(await readFile(await this.findDeliveryFile(deliveryId), "utf8")) as DeliveryState;
	}

	private async saveDelivery(state: DeliveryState): Promise<void> {
		await writeFile(path.join(state.deliveryDir, "delivery.json"), JSON.stringify(state, null, 2));
	}

	private assertOpen(state: DeliveryState): void {
		if (state.closed) throw new Error(`delivery is closed: ${state.deliveryId}`);
	}

	private async writePortableFiles(state: DeliveryState, targetDir = state.deliveryDir): Promise<void> {
		const verification = state.reproductions.map(({ workingCopy: _workingCopy, ...result }) => result);
		const portableManifest = {
			formatVersion: 1,
			deliveryId: state.deliveryId,
			reviewId: state.reviewId,
			versionLabel: state.versionLabel,
			status: state.closed ? "closed_local" : "prepared",
			published: false,
			sent: false,
			recipient: state.manifest.recipient,
			purpose: state.manifest.purpose,
			deliverableScope: state.manifest.deliverableScope,
			explanation: state.manifest.explanation,
			materials: state.manifest.materials.map((material) => ({
				path: material.path,
				deliveryPath: path.join("content", material.snapshotPath),
				purpose: material.purpose,
				limitations: material.limitations ?? [],
			})),
			reviewRecords: state.manifest.reviewRecords,
			m04Record: {
				path: state.manifest.m04Record.preservedRecordPath,
				summary: state.manifest.m04Record.summary,
				requiresNewReview: state.manifest.m04Record.requiresNewReview,
			},
			omittedMaterials: state.manifest.omittedMaterials.map(({ material, reason }) => ({ path: material.path, reason })),
			limitations: state.manifest.limitations,
			unresolved: state.final?.unresolved ?? state.manifest.unresolved,
			verification: {
				status: verification.length === 0 ? "not_run" : "recorded",
				results: verification,
			},
			final: state.final
				? {
					researchStatus: state.final.researchStatus,
					declaredVerificationScope: state.final.verification.declaredScope,
					resumeEntry: state.final.resumeEntry,
					runningTasks: state.final.runningTasks,
					declaredTasksAllStopped: state.final.declaredTasksAllStopped,
				}
				: undefined,
		};
		await writeFile(path.join(targetDir, "manifest.json"), JSON.stringify(portableManifest, null, 2));
		const materialLines = portableManifest.materials.map(
			(material) => `- [${material.path}](<${material.deliveryPath}>) — ${material.purpose}${material.limitations.length ? `；限制：${material.limitations.join("；")}` : ""}`,
		);
		const recordLines = [
			...portableManifest.reviewRecords.map((record) => `- [${record.kind === "self" ? "主 Agent 自查" : `外审：${record.reviewer ?? "未命名"}`}](<${record.path}>)`),
			`- [M04 处理记录](<${portableManifest.m04Record.path}>) — ${portableManifest.m04Record.summary}`,
		];
		const verificationLines = verification.length
			? verification.map((result, index) => `- 运行 ${index + 1}：${result.kind}；执行成功=${result.command.executionSucceeded}；主张验证=${result.claimVerified}`)
			: ["- 未运行复核（not_run）。"];
		const lines = [
			"# 交付说明",
			"",
			`- 研究版本：${state.versionLabel}`,
			`- 接收者：${state.manifest.recipient}`,
			`- 用途：${state.manifest.purpose}`,
			`- 可交付范围：${state.manifest.deliverableScope}`,
			`- 本地交付状态：${state.closed ? "closed_local" : "prepared"}`,
			"- 已发布：否",
			"- 已发送：否",
			"",
			"## 完整说明",
			"",
			state.manifest.explanation,
			"",
			"## 选定材料",
			"",
			...materialLines,
			"",
			"## 审查与处理记录",
			"",
			...recordLines,
			"",
			"## 未提供材料",
			"",
			...(portableManifest.omittedMaterials.length ? portableManifest.omittedMaterials.map((item) => `- ${item.path} — ${item.reason}`) : ["- 无。"]),
			"",
			"## 限制",
			"",
			...(state.manifest.limitations.length ? state.manifest.limitations.map((item) => `- ${item}`) : ["- 无另行说明。"]),
			"",
			"## 未决",
			"",
			...(portableManifest.unresolved.length ? portableManifest.unresolved.map((item) => `- ${item}`) : ["- 无已记录未决。"]),
			"",
			"## 实际复核",
			"",
			...verificationLines,
		];
		if (state.final) {
			lines.push(
				"",
				"## 收口与恢复",
				"",
				`- 研究状态：${state.final.researchStatus}`,
				`- 声明的复核范围：${state.final.verification.declaredScope}`,
				`- 恢复入口：${state.final.resumeEntry}`,
				`- 声明任务是否全部停止：${state.final.declaredTasksAllStopped}`,
			);
		}
		await writeFile(path.join(targetDir, "DELIVERY.md"), `${lines.join("\n")}\n`);
	}

	private async runComparison(root: string, comparison: ComparisonSpec, signal?: AbortSignal): Promise<CommandRecord> {
		requireNonEmpty(comparison.argv, "comparison.argv");
		if (!Number.isFinite(comparison.timeoutMs) || comparison.timeoutMs <= 0) throw new Error("comparison.timeoutMs must be positive");
		return this.runCommand(root, comparison.argv, comparison.cwd, comparison.timeoutMs, signal);
	}

	private async runCommand(root: string, argv: string[], relativeCwd: string | undefined, timeoutMs: number, abortSignal?: AbortSignal): Promise<CommandRecord> {
		const cwd = path.join(root, this.normalizeRelative(relativeCwd ?? ".", "cwd"));
		const cwdReal = await realpath(cwd);
		const rootReal = await realpath(root);
		if (!isInside(rootReal, cwdReal)) throw new Error("cwd escapes the isolated working copy");
		return new Promise((resolve) => {
			const child = spawn(argv[0], argv.slice(1), { cwd, shell: false, env: process.env });
			let stdout = "";
			let stderr = "";
			let stdoutTruncated = false;
			let stderrTruncated = false;
			let timedOut = false;
			let aborted = false;
			let settled = false;
			let killTimer: NodeJS.Timeout | undefined;
			const append = (current: string, chunk: Buffer, markTruncated: () => void): string => {
				const remaining = MAX_CAPTURE_BYTES - Buffer.byteLength(current);
				if (remaining <= 0) {
					markTruncated();
					return current;
				}
				const buffer = chunk.length > remaining ? chunk.subarray(0, remaining) : chunk;
				if (buffer.length < chunk.length) markTruncated();
				return current + buffer.toString();
			};
			const terminate = () => {
				child.kill("SIGTERM");
				killTimer = setTimeout(() => child.kill("SIGKILL"), 250);
			};
			const finish = (record: CommandRecord) => {
				if (settled) return;
				settled = true;
				if (killTimer) clearTimeout(killTimer);
				abortSignal?.removeEventListener("abort", onAbort);
				resolve(record);
			};
			const onAbort = () => {
				aborted = true;
				terminate();
			};
			child.stdout.on("data", (chunk: Buffer) => (stdout = append(stdout, chunk, () => (stdoutTruncated = true))));
			child.stderr.on("data", (chunk: Buffer) => (stderr = append(stderr, chunk, () => (stderrTruncated = true))));
			child.once("error", (error) => {
				clearTimeout(timer);
				finish({ argv, cwd: path.relative(root, cwd) || ".", timeoutMs, exitCode: null, signal: null, timedOut: false, aborted, stdout, stderr: `${stderr}${error.message}`, stdoutTruncated, stderrTruncated, executionSucceeded: false });
			});
			const timer = setTimeout(() => {
				timedOut = true;
				terminate();
			}, timeoutMs);
			abortSignal?.addEventListener("abort", onAbort, { once: true });
			if (abortSignal?.aborted) onAbort();
			child.once("close", (exitCode, signal) => {
				clearTimeout(timer);
				finish({ argv, cwd: path.relative(root, cwd) || ".", timeoutMs, exitCode, signal, timedOut, aborted, stdout, stderr, stdoutTruncated, stderrTruncated, executionSucceeded: exitCode === 0 && !timedOut && !aborted });
			});
		});
	}
}

export type * from "./types.js";

import assert from "node:assert/strict";
import { cp, mkdtemp, readFile, readdir, stat, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import { ReviewDeliveryCore } from "../../src/review-delivery/core.js";
import type { M08PrepareResult, M09PrepareResult, ReviewExecutor, ReviewExecutorResult } from "../../src/review-delivery/types.js";

const reviewResult = (reviewer: string): ReviewExecutorResult => ({
	rawReport: `Raw external review from ${reviewer}`,
	summary: `${reviewer} reviewed the frozen material`,
	readCoverage: ["problem.txt", "result.txt"],
	limitations: ["offline fixture review"],
	structuredFindingsParsed: false,
});

async function fixture(executor: ReviewExecutor = async ({ reviewer }) => reviewResult(reviewer)) {
	const workspace = await mkdtemp(path.join(tmpdir(), "m08-m09-workspace-"));
	await writeFile(path.join(workspace, "problem.txt"), "original problem\n");
	await writeFile(path.join(workspace, "result.txt"), "frozen result\n");
	await writeFile(path.join(workspace, "self-review.md"), "self review evidence\n");
	await writeFile(path.join(workspace, "m04.md"), "M04 handled findings\n");
	const core = new ReviewDeliveryCore({ workspaceRoot: workspace, reviewExecutor: executor });
	return { workspace, core };
}

async function prepare(core: ReviewDeliveryCore): Promise<M08PrepareResult> {
	return core.m08Prepare({
		originalProblemPath: "problem.txt",
		goal: "Answer the original problem",
		scope: "Fixture scope",
		claims: ["The saved result is conditional"],
		versionLabel: "v1",
		materials: [
			{ path: "problem.txt", purpose: "Original problem" },
			{ path: "result.txt", purpose: "Main result", limitations: ["fixture"] },
		],
	});
}

async function completeReview(core: ReviewDeliveryCore): Promise<M08PrepareResult> {
	const run = await prepare(core);
	const reviewed = await core.m08Review({
		reviewId: run.reviewId,
		selfReview: {
			reportPath: "self-review.md",
			summary: "Self review completed",
			readCoverageDeclared: ["problem.txt", "result.txt"],
			limitations: [],
		},
		reviewers: ["reviewer-a"],
	});
	assert.equal(reviewed.status, "awaiting_m04");
	assert.equal(reviewed.sciencePassDeclared, false);
	assert.match(await readFile(reviewed.selfReview.preservedReportPath, "utf8"), /self review evidence/);
	return run;
}

async function prepareDelivery(core: ReviewDeliveryCore, run: M08PrepareResult): Promise<M09PrepareResult> {
	return core.m09Prepare({
		reviewId: run.reviewId,
		versionLabel: "v1",
		m04: { reviewId: run.reviewId, versionLabel: "v1", recordPath: "m04.md", summary: "Handled", requiresNewReview: false },
		recipient: "research owner",
		purpose: "continue work",
		deliverableScope: "conditional fixture result",
		explanation: "The result remains conditional.",
		selectedMaterials: ["result.txt"],
		omittedMaterialReasons: { "problem.txt": "Recipient already has the original problem; omission is explicit." },
		limitations: ["fixture only"],
		unresolved: ["real-world validation"],
	});
}

test("m08_prepare freezes ordinary files and rejects missing original problem or escaping symlinks", async () => {
	const { workspace, core } = await fixture();
	await assert.rejects(
		core.m08Prepare({
			originalProblemPath: "missing.txt",
			goal: "goal",
			scope: "scope",
			claims: ["claim"],
			versionLabel: "v1",
			materials: [{ path: "result.txt", purpose: "result" }],
		}),
		/originalProblemPath/,
	);
	const outside = path.join(await mkdtemp(path.join(tmpdir(), "outside-")), "outside.txt");
	await writeFile(outside, "outside");
	await symlink(outside, path.join(workspace, "escape.txt"));
	await assert.rejects(
		core.m08Prepare({
			originalProblemPath: "problem.txt",
			goal: "goal",
			scope: "scope",
			claims: ["claim"],
			versionLabel: "v1",
			materials: [{ path: "problem.txt", purpose: "problem" }, { path: "escape.txt", purpose: "escape" }],
		}),
		/regular non-symlink/,
	);
	const run = await prepare(core);
	await writeFile(path.join(workspace, "result.txt"), "changed source\n");
	assert.equal(await readFile(path.join(run.snapshotDir, "result.txt"), "utf8"), "frozen result\n");
});

test("failed prepare leaves no published review directory", async () => {
	const { workspace, core } = await fixture();
	await assert.rejects(
		core.m08Prepare({
			originalProblemPath: "problem.txt",
			goal: "goal",
			scope: "scope",
			claims: ["claim"],
			versionLabel: "v1",
			materials: [{ path: "problem.txt", purpose: "problem" }, { path: "absent.txt", purpose: "missing" }],
		}),
	);
	const entries = await readdir(path.join(workspace, ".agent", "private", "review-delivery"));
	assert.deepEqual(entries, []);
});

test("m08_review requires self-review, preserves raw reports, and retries only failures", async () => {
	const calls = new Map<string, number>();
	const executor: ReviewExecutor = async ({ reviewer, originalProblemPath }) => {
		assert.equal(originalProblemPath, "problem.txt");
		calls.set(reviewer, (calls.get(reviewer) ?? 0) + 1);
		if (reviewer === "reviewer-b" && calls.get(reviewer) === 1) throw new Error("temporary failure");
		return reviewResult(reviewer);
	};
	const { core } = await fixture(executor);
	const run = await prepare(core);
	const first = await core.m08Review({
		reviewId: run.reviewId,
		selfReview: { reportPath: "self-review.md", summary: "done", readCoverageDeclared: ["problem.txt"], limitations: [] },
		reviewers: ["reviewer-a", "reviewer-b"],
	});
	assert.equal(first.status, "reviewing");
	assert.equal(first.allReviewersSucceeded, false);
	assert.equal(first.reviewers[0]?.result?.rawReport, "Raw external review from reviewer-a");
	const second = await core.m08Review({
		reviewId: run.reviewId,
		selfReview: { reportPath: "self-review.md", summary: "done", readCoverageDeclared: ["problem.txt"], limitations: [] },
		reviewers: ["reviewer-a", "reviewer-b"],
	});
	assert.equal(second.status, "awaiting_m04");
	assert.equal(calls.get("reviewer-a"), 1);
	assert.equal(calls.get("reviewer-b"), 2);
	await assert.rejects(
		core.m08Review({
			reviewId: run.reviewId,
			selfReview: { reportPath: "self-review.md", summary: "changed", readCoverageDeclared: ["problem.txt"], limitations: [] },
			reviewers: ["reviewer-a", "reviewer-b"],
		}),
		/self-review evidence is frozen/,
	);
	await assert.rejects(
		core.m08Review({
			reviewId: run.reviewId,
			selfReview: { reportPath: "self-review.md", summary: "done", readCoverageDeclared: ["problem.txt"], limitations: [] },
			reviewers: ["reviewer-a"],
		}),
		/reviewer roster is frozen/,
	);
});

test("concurrent review of the same run is rejected", async () => {
	let release: (() => void) | undefined;
	const gate = new Promise<void>((resolve) => (release = resolve));
	const { workspace, core } = await fixture(async ({ reviewer }) => {
		await gate;
		return reviewResult(reviewer);
	});
	const run = await prepare(core);
	const input = {
		reviewId: run.reviewId,
		selfReview: { reportPath: "self-review.md", summary: "done", readCoverageDeclared: ["problem.txt"], limitations: [] },
		reviewers: ["reviewer-a"],
	};
	const active = core.m08Review(input);
	const secondCore = new ReviewDeliveryCore({ workspaceRoot: workspace, reviewExecutor: async ({ reviewer }) => reviewResult(reviewer) });
	await assert.rejects(secondCore.m08Review(input), /operation already active/);
	release?.();
	await active;
});

test("m09_prepare requires completed same-version M04 evidence and omission reasons", async () => {
	const { core } = await fixture();
	const run = await completeReview(core);
	const base = {
		reviewId: run.reviewId,
		versionLabel: "v1",
		m04: { reviewId: run.reviewId, versionLabel: "v2", recordPath: "m04.md", summary: "handled", requiresNewReview: false },
		recipient: "owner",
		purpose: "handoff",
		deliverableScope: "scope",
		explanation: "explanation",
		selectedMaterials: ["result.txt"],
		omittedMaterialReasons: { "problem.txt": "explicit omission" },
		limitations: [],
		unresolved: [],
	};
	await assert.rejects(core.m09Prepare(base), /versionLabel/);
	await assert.rejects(core.m09Prepare({ ...base, m04: { ...base.m04, versionLabel: "v1", requiresNewReview: true } }), /new M08 review/);
	await assert.rejects(core.m09Prepare({ ...base, m04: { ...base.m04, versionLabel: "v1" }, omittedMaterialReasons: {} }), /omission reason/);
	const delivery = await prepareDelivery(core, run);
	assert.equal(delivery.published, false);
	assert.equal(delivery.sent, false);
	assert.match(await readFile(path.join(delivery.deliveryDir, delivery.manifest.m04Record.preservedRecordPath), "utf8"), /M04 handled/);
});

test("m09_reproduce uses a separate copy, records failures, and never declares a claim verified", async () => {
	const { workspace, core } = await fixture();
	const run = await completeReview(core);
	const delivery = await prepareDelivery(core, run);
	const deliveredFile = path.join(delivery.deliveryDir, "content", "result.txt");
	const result = await core.m09Reproduce({
		deliveryId: delivery.deliveryId,
		kind: "analysis_rerun",
		argv: [process.execPath, "-e", "require('fs').writeFileSync('result.txt','working copy changed')"],
		timeoutMs: 5_000,
	});
	assert.equal(result.command.executionSucceeded, true);
	assert.equal(result.claimVerified, false);
	assert.equal(result.sandboxed, false);
	assert.equal(await readFile(path.join(workspace, "result.txt"), "utf8"), "frozen result\n");
	assert.equal(await readFile(deliveredFile, "utf8"), "frozen result\n");
	const failed = await core.m09Reproduce({
		deliveryId: delivery.deliveryId,
		kind: "redraw",
		argv: [process.execPath, "-e", "process.exit(7)"],
		timeoutMs: 5_000,
	});
	assert.equal(failed.command.exitCode, 7);
	assert.equal(failed.command.executionSucceeded, false);
	assert.equal(failed.claimVerified, false);
});

test("m09_reproduce force-terminates a command that ignores the timeout signal", async () => {
	const { core } = await fixture();
	const run = await completeReview(core);
	const delivery = await prepareDelivery(core, run);
	const result = await core.m09Reproduce({
		deliveryId: delivery.deliveryId,
		kind: "full_recalculation",
		argv: [process.execPath, "-e", "process.on('SIGTERM',()=>{});setInterval(()=>{},1000)"],
		timeoutMs: 50,
	});
	assert.equal(result.command.timedOut, true);
	assert.equal(result.command.executionSucceeded, false);
	assert.equal(result.command.signal, "SIGKILL");
});

test("m09_reproduce records tool cancellation without reporting execution success", async () => {
	const { core } = await fixture();
	const run = await completeReview(core);
	const delivery = await prepareDelivery(core, run);
	const controller = new AbortController();
	setTimeout(() => controller.abort(), 30);
	const result = await core.m09Reproduce({
		deliveryId: delivery.deliveryId,
		kind: "analysis_rerun",
		argv: [process.execPath, "-e", "setInterval(()=>{},1000)"],
		timeoutMs: 2_000,
		signal: controller.signal,
	});
	assert.equal(result.command.aborted, true);
	assert.equal(result.command.executionSucceeded, false);
});

test("portable delivery remains readable after moving to a new directory", async () => {
	const { core } = await fixture();
	const run = await completeReview(core);
	const delivery = await prepareDelivery(core, run);
	const moved = await mkdtemp(path.join(tmpdir(), "portable-delivery-"));
	await cp(delivery.deliveryDir, moved, { recursive: true });
	const markdown = await readFile(path.join(moved, "DELIVERY.md"), "utf8");
	const links = [...markdown.matchAll(/\]\(<([^>]+)>\)/g)].map((match) => match[1]);
	assert.ok(links.length >= 4);
	for (const relative of links) assert.equal((await stat(path.join(moved, relative))).isFile(), true);
	const manifest = JSON.parse(await readFile(path.join(moved, "manifest.json"), "utf8")) as { materials: Array<{ deliveryPath: string }>; verification: { status: string } };
	assert.equal(manifest.verification.status, "not_run");
	assert.equal((await stat(path.join(moved, manifest.materials[0]!.deliveryPath))).isFile(), true);
	assert.equal(JSON.stringify(manifest).includes(delivery.deliveryDir), false);
});

test("m09_finalize closes only the local delivery and preserves active task declarations", async () => {
	const { core } = await fixture();
	const run = await completeReview(core);
	const delivery = await prepareDelivery(core, run);
	const final = await core.m09Finalize({
		deliveryId: delivery.deliveryId,
		researchStatus: "conditional result",
		declaredVerificationScope: "No reproduction was run",
		unresolved: ["external replication"],
		resumeEntry: "Re-open the unresolved evidence question",
		runningTasks: [{ id: "task-1", description: "External computation", status: "running" }],
	});
	assert.equal(final.status, "closed_local");
	assert.equal(final.verification.status, "not_run");
	assert.equal(final.published, false);
	assert.equal(final.sent, false);
	assert.equal(final.declaredTasksAllStopped, false);
	assert.equal(final.runningTasks[0]?.status, "running");
	assert.deepEqual(final.unresolved, ["real-world validation", "external replication"]);
	const portableManifest = await readFile(path.join(delivery.deliveryDir, "manifest.json"), "utf8");
	const deliveryDocument = await readFile(path.join(delivery.deliveryDir, "DELIVERY.md"), "utf8");
	assert.match(portableManifest, /real-world validation/);
	assert.match(portableManifest, /external replication/);
	assert.match(deliveryDocument, /real-world validation/);
	assert.match(deliveryDocument, /external replication/);
	await assert.rejects(
		core.m09Reproduce({ deliveryId: delivery.deliveryId, kind: "redraw", argv: [process.execPath, "-e", ""], timeoutMs: 1_000 }),
		/delivery is closed/,
	);
	await assert.rejects(
		core.m09Finalize({
			deliveryId: delivery.deliveryId,
			researchStatus: "again",
			declaredVerificationScope: "none",
			unresolved: [],
			resumeEntry: "none",
			runningTasks: [],
		}),
		/delivery is closed/,
	);
});

test("concurrent reproduction and finalization for one delivery cannot overlap", async () => {
	const { workspace, core } = await fixture();
	const run = await completeReview(core);
	const delivery = await prepareDelivery(core, run);
	const active = core.m09Reproduce({
		deliveryId: delivery.deliveryId,
		kind: "full_recalculation",
		argv: [process.execPath, "-e", "setTimeout(() => {}, 100)"],
		timeoutMs: 2_000,
	});
	const secondCore = new ReviewDeliveryCore({ workspaceRoot: workspace });
	await assert.rejects(
		secondCore.m09Finalize({
			deliveryId: delivery.deliveryId,
			researchStatus: "conditional",
			declaredVerificationScope: "active reproduction",
			unresolved: [],
			resumeEntry: "wait",
			runningTasks: [],
		}),
		/operation already active/,
	);
	await active;
});

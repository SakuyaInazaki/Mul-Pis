import { lstat, readFile, readdir, realpath } from "node:fs/promises";
import path from "node:path";
import {
	createAgentSession,
	createReadToolDefinition,
	DefaultResourceLoader,
	ModelRuntime,
	resolveCliModel,
	SessionManager,
	type AgentSession,
	type ResourceLoader,
	type ToolDefinition,
} from "@earendil-works/pi-coding-agent";
import { Type } from "@earendil-works/pi-ai";
import type {
	ReviewExecutor,
	ReviewExecutorRequest,
	ReviewExecutorResult,
} from "./types.js";

const P08E = `请对所附研究成果做综合审查。本轮不是润色。先从原始问题和明确澄清中理解目标；执行 Agent 的摘要、自查和“已验证”声明都不是标准答案。

核对目标同一性，以及每项主要结论的关键前提、推理、实际依据、适用条件和表述范围。直接读取清单中的必要原始产物。区分演绎证明、条件性模型结果、有限数值检验和经验支持。没有实际执行的检查不得写成验证通过。

每条实质意见必须给出：准确位置、问题、依据、影响范围、最小补证或修正办法，并分别标明成立程度（error / missing_evidence / insufficient_conditions / undetermined / suggestion）和严重度（blocking / major / minor / advisory）。最后报告实际读取范围、未读取材料、工具限制、目标回应程度、主要结论支持范围、阻塞问题和可交付范围。不得输出总分代替判断。`;

const REVIEW_SYSTEM_PROMPT = `你是独立成果审查者。只依据本轮给出的原问题、澄清和冻结材料审查；不要猜测未提供内容，不把执行者自查或其他审查意见当标准答案。必须使用 snapshot_read 或 snapshot_list 读取必要原始材料，并如实报告实际读取覆盖。PDF 解析和程序执行不在当前工具能力内。`;

const isInside = (root: string, candidate: string): boolean =>
	candidate === root || candidate.startsWith(`${root}${path.sep}`);

async function resolveSnapshotPath(snapshotRoot: string, requested: string): Promise<string> {
	if (!requested.trim()) throw new Error("path must not be empty");
	const rootReal = await realpath(snapshotRoot);
	const candidate = path.isAbsolute(requested) ? path.resolve(requested) : path.resolve(rootReal, requested);
	const candidateReal = await realpath(candidate);
	if (!isInside(rootReal, candidateReal)) throw new Error("snapshot path resolves outside the frozen snapshot");
	return candidateReal;
}

export type SnapshotToolSet = {
	tools: ToolDefinition<any, any>[];
	readCoverage: Set<string>;
};

export function createSnapshotTools(snapshotDir: string): SnapshotToolSet {
	const readCoverage = new Set<string>();
	const baseRead = createReadToolDefinition(snapshotDir, {
		operations: {
			access: async (requested) => {
				const resolved = await resolveSnapshotPath(snapshotDir, requested);
				if (path.extname(resolved).toLowerCase() === ".pdf") {
					throw new Error("PDF parsing is not supported by snapshot_read");
				}
				const stat = await lstat(resolved);
				if (!stat.isFile()) throw new Error("snapshot_read accepts files only");
			},
			readFile: async (requested) => {
				const resolved = await resolveSnapshotPath(snapshotDir, requested);
				if (path.extname(resolved).toLowerCase() === ".pdf") {
					throw new Error("PDF parsing is not supported by snapshot_read");
				}
				readCoverage.add(path.relative(await realpath(snapshotDir), resolved));
				return readFile(resolved);
			},
			detectImageMimeType: async (requested) => {
				const resolved = await resolveSnapshotPath(snapshotDir, requested);
				const extension = path.extname(resolved).toLowerCase();
				return ({ ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp" } as Record<string, string>)[extension];
			},
		},
	});
	const snapshotRead = { ...baseRead, name: "snapshot_read", label: "snapshot_read" } as unknown as ToolDefinition<any, any>;
	const snapshotList: ToolDefinition = {
		name: "snapshot_list",
		label: "snapshot_list",
		description: "List a directory inside the frozen review snapshot.",
		parameters: Type.Object({ path: Type.Optional(Type.String({ description: "Snapshot-relative directory" })) }),
		async execute(_toolCallId, params) {
			const resolved = await resolveSnapshotPath(snapshotDir, (params as { path?: string }).path ?? ".");
			const stat = await lstat(resolved);
			if (!stat.isDirectory()) throw new Error("snapshot_list accepts directories only");
			const entries = await readdir(resolved, { withFileTypes: true });
			return {
				content: [{ type: "text", text: entries.map((entry) => `${entry.isDirectory() ? "dir" : "file"}\t${entry.name}`).join("\n") }],
				details: { path: path.relative(await realpath(snapshotDir), resolved) || "." },
			};
		},
	};
	return { tools: [snapshotRead, snapshotList], readCoverage };
}

export async function createReviewResourceLoader(snapshotDir: string): Promise<ResourceLoader> {
	const loader = new DefaultResourceLoader({
		cwd: snapshotDir,
		agentDir: path.join(snapshotDir, ".pi-review-empty-agent"),
		noExtensions: true,
		noSkills: true,
		noPromptTemplates: true,
		noThemes: true,
		noContextFiles: true,
		systemPrompt: REVIEW_SYSTEM_PROMPT,
	});
	await loader.reload();
	return loader;
}

type SessionLike = Pick<AgentSession, "prompt" | "messages" | "dispose" | "abort" | "getActiveToolNames">;

export type PiReviewExecutorOptions = {
	signal?: AbortSignal;
	modelRuntime?: ModelRuntime;
	createSession?: typeof createAgentSession;
};

const THINKING_LEVELS = new Set(["off", "minimal", "low", "medium", "high", "xhigh", "max"]);

export function parseReviewer(reviewer: string): { provider: string; modelId: string; thinkingLevel?: string } {
	const slash = reviewer.indexOf("/");
	if (slash <= 0 || slash === reviewer.length - 1) {
		throw new Error("reviewer must explicitly use provider/model or provider/model:thinking");
	}
	const provider = reviewer.slice(0, slash);
	const modelAndThinking = reviewer.slice(slash + 1);
	const colon = modelAndThinking.lastIndexOf(":");
	const suffix = colon > 0 ? modelAndThinking.slice(colon + 1) : "";
	return colon > 0 && THINKING_LEVELS.has(suffix)
		? { provider, modelId: modelAndThinking.slice(0, colon), thinkingLevel: modelAndThinking.slice(colon + 1) }
		: { provider, modelId: modelAndThinking };
}

function textOfLastSuccessfulAssistant(messages: readonly unknown[]): string {
	const lastAssistant = [...messages]
		.reverse()
		.find((candidate) => (candidate as { role?: string }).role === "assistant") as
		| { stopReason?: string; errorMessage?: string; content?: unknown }
		| undefined;
	if (!lastAssistant) throw new Error("reviewer produced no assistant message");
	if (lastAssistant.stopReason !== "stop") {
		throw new Error(
			`reviewer did not complete normally (stopReason=${lastAssistant.stopReason ?? "missing"})${lastAssistant.errorMessage ? `: ${lastAssistant.errorMessage}` : ""}`,
		);
	}
	const blocks = Array.isArray(lastAssistant.content) ? lastAssistant.content : [];
	const text = blocks
		.filter((block): block is { type: "text"; text: string } => {
			const candidate = block as { type?: string; text?: unknown };
			return candidate.type === "text" && typeof candidate.text === "string";
		})
		.map((block) => block.text)
		.join("\n")
		.trim();
	if (!text) throw new Error("reviewer's final assistant message contained no visible text");
	return text;
}

function buildReviewPrompt(request: ReviewExecutorRequest): string {
	const materialList = request.materials
		.map((material) => `- ${material.snapshotPath}\n  用途：${material.purpose}\n  限制：${material.limitations?.join("；") || "无另行说明"}`)
		.join("\n");
	return `${P08E}\n\n第一步必须先用 snapshot_read 完整读取原始问题文件：${request.originalProblemPath}。在此之前不要采用下面的目标整理或主张列表作为审查标准。\n\n执行侧提供的范围背景（仅用于定位材料，不是标准答案）：\n目标整理：${request.goal}\n审查范围：${request.scope}\n待审主要主张：\n${request.claims.map((claim) => `- ${claim}`).join("\n")}\n\n冻结版本：${request.versionLabel}\n\n冻结材料清单：\n${materialList}\n\n请输出可见文本审查报告，并在结尾用“实际读取覆盖”“未读取/限制”两个标题明确列出。`;
}

export function createPiReviewExecutor(options: PiReviewExecutorOptions = {}): ReviewExecutor {
	return async (request): Promise<ReviewExecutorResult> => {
		const parsed = parseReviewer(request.reviewer);
		const runtime = options.modelRuntime ?? (await ModelRuntime.create());
		const resolved = resolveCliModel({ cliModel: request.reviewer, modelRuntime: runtime });
		if (resolved.error || !resolved.model) throw new Error(resolved.error ?? `model not found: ${request.reviewer}`);
		if (resolved.model.provider !== parsed.provider || resolved.model.id !== parsed.modelId) {
			throw new Error(`reviewer resolved unexpectedly: ${resolved.model.provider}/${resolved.model.id}`);
		}
		const { tools, readCoverage } = createSnapshotTools(request.snapshotDir);
		const loader = await createReviewResourceLoader(request.snapshotDir);
		const createSession = options.createSession ?? createAgentSession;
		let session: SessionLike | undefined;
		let aborted = false;
		const onAbort = () => {
			aborted = true;
			void session?.abort();
		};
		options.signal?.addEventListener("abort", onAbort, { once: true });
		try {
			if (options.signal?.aborted) throw new Error("review aborted before session creation");
			const created = await createSession({
				cwd: request.snapshotDir,
				model: resolved.model,
				thinkingLevel: resolved.thinkingLevel,
				modelRuntime: runtime,
				noTools: "builtin",
				tools: ["snapshot_read", "snapshot_list"],
				customTools: tools,
				resourceLoader: loader,
				sessionManager: SessionManager.inMemory(request.snapshotDir),
			});
			session = created.session;
			const active = [...session.getActiveToolNames()].sort();
			if (active.join(",") !== "snapshot_list,snapshot_read") {
				throw new Error(`unsafe reviewer tool set: ${active.join(",") || "(empty)"}`);
			}
			await session.prompt(buildReviewPrompt(request));
			if (aborted || options.signal?.aborted) throw new Error("review aborted");
			const requiredOriginal = path.normalize(request.originalProblemPath);
			if (!readCoverage.has(requiredOriginal)) {
				throw new Error(`reviewer did not read the frozen original problem: ${request.originalProblemPath}`);
			}
			const summary = textOfLastSuccessfulAssistant(session.messages);
			return {
				rawReport: summary,
				summary,
				readCoverage: [...readCoverage].sort(),
				limitations: ["Review session cannot execute programs.", "PDF parsing is not supported; PDF files require a separately extracted artifact."],
				structuredFindingsParsed: false,
			};
		} finally {
			options.signal?.removeEventListener("abort", onAbort);
			session?.dispose();
		}
	};
}

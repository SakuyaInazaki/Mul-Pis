export type MaterialSpec = {
	path: string;
	purpose: string;
	limitations?: string[];
};

export type SnapshotMaterial = MaterialSpec & {
	snapshotPath: string;
	size: number;
	mtimeMs: number;
};

export type M08PrepareInput = {
	originalProblemPath: string;
	goal: string;
	scope: string;
	claims: string[];
	versionLabel: string;
	materials: MaterialSpec[];
};

export type M08PrepareResult = {
	reviewId: string;
	status: "prepared";
	versionLabel: string;
	originalProblemPath: string;
	snapshotDir: string;
	materials: SnapshotMaterial[];
};

export type SelfReviewInput = {
	reportPath: string;
	summary: string;
	readCoverageDeclared: string[];
	limitations: string[];
};

export type StoredSelfReview = SelfReviewInput & {
	preservedReportPath: string;
	evidenceSize: number;
	evidenceMtimeMs: number;
};

export type ReviewFinding = {
	location: string;
	issue: string;
	basis: string;
	impact: string;
	minimumRemedy: string;
	establishment: "error" | "missing_evidence" | "insufficient_conditions" | "undetermined" | "suggestion";
	severity: "blocking" | "major" | "minor" | "advisory";
};

export type ReviewExecutorRequest = {
	reviewer: string;
	originalProblemPath: string;
	goal: string;
	scope: string;
	claims: string[];
	versionLabel: string;
	snapshotDir: string;
	materials: SnapshotMaterial[];
};

export type ReviewExecutorResult = {
	rawReport: string;
	summary: string;
	readCoverage: string[];
	limitations: string[];
	structuredFindingsParsed: boolean;
	findings?: ReviewFinding[];
};

export type ReviewExecutor = (request: ReviewExecutorRequest) => Promise<ReviewExecutorResult>;

export type ReviewerRecord = {
	reviewer: string;
	status: "succeeded" | "failed";
	result?: ReviewExecutorResult;
	error?: string;
};

export type M08ReviewInput = {
	reviewId: string;
	selfReview: SelfReviewInput;
	reviewers: string[];
};

export type M08ReviewResult = {
	reviewId: string;
	status: "reviewing" | "awaiting_m04";
	versionLabel: string;
	selfReview: StoredSelfReview;
	reviewers: ReviewerRecord[];
	allReviewersSucceeded: boolean;
	sciencePassDeclared: false;
};

export type M04Record = {
	reviewId: string;
	versionLabel: string;
	recordPath: string;
	summary: string;
	requiresNewReview: boolean;
};

export type M09PrepareInput = {
	reviewId: string;
	versionLabel: string;
	m04: M04Record;
	recipient: string;
	purpose: string;
	deliverableScope: string;
	explanation: string;
	selectedMaterials: string[];
	omittedMaterialReasons: Record<string, string>;
	limitations: string[];
	unresolved: string[];
};

export type M09PrepareResult = {
	deliveryId: string;
	status: "prepared";
	published: false;
	sent: false;
	reviewId: string;
	versionLabel: string;
	deliveryDir: string;
	deliveryDocumentPath: string;
	portableManifestPath: string;
	manifest: {
		recipient: string;
		purpose: string;
		deliverableScope: string;
		explanation: string;
		m04Record: M04Record & { preservedRecordPath: string };
		reviewRecords: Array<{ kind: "self" | "external"; reviewer?: string; path: string }>;
		materials: SnapshotMaterial[];
		limitations: string[];
		unresolved: string[];
		omittedMaterials: Array<{ material: SnapshotMaterial; reason: string }>;
	};
};

export type ReproductionKind = "redraw" | "analysis_rerun" | "full_recalculation";

export type ComparisonSpec = {
	argv: string[];
	cwd?: string;
	method: string;
	timeoutMs: number;
};

export type M09ReproduceInput = {
	deliveryId: string;
	kind: ReproductionKind;
	argv: string[];
	cwd?: string;
	timeoutMs: number;
	signal?: AbortSignal;
	comparison?: ComparisonSpec;
};

export type CommandRecord = {
	argv: string[];
	cwd: string;
	timeoutMs: number;
	exitCode: number | null;
	signal: NodeJS.Signals | null;
	timedOut: boolean;
	aborted: boolean;
	stdout: string;
	stderr: string;
	stdoutTruncated: boolean;
	stderrTruncated: boolean;
	executionSucceeded: boolean;
};

export type M09ReproduceResult = {
	deliveryId: string;
	status: "verification_recorded";
	kind: ReproductionKind;
	environment: { node: string; platform: NodeJS.Platform; arch: string };
	workingCopy: string;
	sandboxed: false;
	command: CommandRecord;
	comparison?: CommandRecord & { method: string };
	claimVerified: false;
};

export type RunningTask = {
	id: string;
	description: string;
	status: "running" | "unknown" | "stopped";
};

export type M09FinalizeInput = {
	deliveryId: string;
	researchStatus: string;
	declaredVerificationScope: string;
	unresolved: string[];
	resumeEntry: string;
	runningTasks: RunningTask[];
};

export type M09FinalizeResult = {
	deliveryId: string;
	deliveryDir: string;
	closed: true;
	stopRequested: true;
	status: "closed_local";
	published: false;
	sent: false;
	researchStatus: string;
	verification: {
		declaredScope: string;
		status: "not_run" | "recorded";
		results: M09ReproduceResult[];
	};
	unresolved: string[];
	resumeEntry: string;
	runningTasks: RunningTask[];
	declaredTasksAllStopped: boolean;
};

export type CoreOptions = {
	workspaceRoot: string;
	runsRoot?: string;
	reviewExecutor?: ReviewExecutor;
};

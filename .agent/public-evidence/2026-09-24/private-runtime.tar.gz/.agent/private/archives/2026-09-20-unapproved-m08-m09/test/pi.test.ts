import assert from "node:assert/strict";
import { mkdtemp, mkdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import { InMemoryCredentialStore } from "@earendil-works/pi-ai";
import { createAgentSession, ModelRuntime, SessionManager } from "@earendil-works/pi-coding-agent";
import extension, { finalizeReceipt } from "../.pi/extensions/research-review.ts";
import {
	createPiReviewExecutor,
	createReviewResourceLoader,
	createSnapshotTools,
	parseReviewer,
} from "../src/review-delivery/pi.js";

async function fixture(): Promise<{ root: string; snapshot: string }> {
	const root = await mkdtemp(path.join(tmpdir(), "review-pi-test-"));
	const snapshot = path.join(root, "snapshot");
	await mkdir(path.join(snapshot, "nested"), { recursive: true });
	await writeFile(path.join(snapshot, "problem.txt"), "original problem");
	await writeFile(path.join(snapshot, "nested", "result.txt"), "result");
	await writeFile(path.join(snapshot, "paper.pdf"), "%PDF-not-parsed");
	await writeFile(path.join(root, "outside.txt"), "outside");
	return { root, snapshot };
}

test("extension registers exactly the five M08/M09 tools", () => {
	const registered: Array<{ name: string; execute: (...args: any[]) => Promise<any> }> = [];
	extension({ registerTool: (tool: any) => registered.push(tool) } as any);
	assert.deepEqual(
		registered.map((tool) => tool.name),
		["m08_prepare", "m08_review", "m09_prepare", "m09_reproduce", "m09_finalize"],
	);
});

test("reviewer parsing preserves model suffixes that are not Pi thinking levels", () => {
	assert.deepEqual(parseReviewer("provider/model:free"), { provider: "provider", modelId: "model:free" });
	assert.deepEqual(parseReviewer("provider/vendor/model:effort"), { provider: "provider", modelId: "vendor/model:effort" });
	assert.deepEqual(parseReviewer("provider/vendor/model:high"), {
		provider: "provider",
		modelId: "vendor/model",
		thinkingLevel: "high",
	});
});

test("M09 finalize emits a readable receipt and only requests current-turn termination", () => {
	const receipt = finalizeReceipt({
		deliveryId: "delivery-1",
		deliveryDir: "/tmp/delivery-1",
		closed: true,
		stopRequested: true,
		status: "closed_local",
		published: false,
		sent: false,
		researchStatus: "阶段成果",
		verification: { declaredScope: "入口检查", status: "not_run", results: [] },
		unresolved: ["限制 A"],
		resumeEntry: "DELIVERY.md",
		runningTasks: [{ id: "job-1", description: "external job", status: "unknown" }],
		declaredTasksAllStopped: false,
	});
	assert.equal(receipt.terminate, true);
	assert.match(receipt.content[0].text, /交付目录：\/tmp\/delivery-1/);
	assert.match(receipt.content[0].text, /job-1\(unknown\)/);
	assert.match(receipt.content[0].text, /不关闭 Pi 会话或进程/);
});

test("snapshot tools read only real files inside the frozen root and record coverage", async () => {
	const { snapshot } = await fixture();
	const { tools, readCoverage } = createSnapshotTools(snapshot);
	const read = tools.find((tool) => tool.name === "snapshot_read");
	assert.ok(read);
	const result = await read.execute("call", { path: "nested/result.txt" }, undefined, undefined, undefined as any);
	assert.match((result.content[0] as { text: string }).text, /result/);
	assert.deepEqual([...readCoverage], [path.join("nested", "result.txt")]);
	await assert.rejects(() => read.execute("call", { path: "../outside.txt" }, undefined, undefined, undefined as any), /outside|escapes/);
	await assert.rejects(() => read.execute("call", { path: "paper.pdf" }, undefined, undefined, undefined as any), /PDF parsing is not supported/);
});

test("Pi review executor uses only bounded tools and returns visible assistant text", async () => {
	const { snapshot } = await fixture();
	const credentials = new InMemoryCredentialStore();
	const runtime = await ModelRuntime.create({ credentials, allowModelNetwork: false });
	let prompt = "";
	let disposed = false;
	let snapshotRead: any;
	const fakeSession = {
		getActiveToolNames: () => ["snapshot_read", "snapshot_list"],
		prompt: async (value: string) => {
			prompt = value;
			await snapshotRead.execute("read-original", { path: "problem.txt" }, undefined, undefined, undefined);
		},
		messages: [
			{ role: "assistant", content: [{ type: "thinking", thinking: "private" }, { type: "text", text: "visible review" }], stopReason: "stop" },
		],
		abort: async () => {},
		dispose: () => {
			disposed = true;
		},
	};
	const executor = createPiReviewExecutor({
		modelRuntime: runtime,
		createSession: (async (options: any) => {
			assert.equal(options.noTools, "builtin");
			assert.deepEqual(options.tools, ["snapshot_read", "snapshot_list"]);
			assert.deepEqual(options.customTools.map((tool: any) => tool.name), ["snapshot_read", "snapshot_list"]);
			snapshotRead = options.customTools[0];
			return { session: fakeSession, extensionsResult: {} };
		}) as any,
	});
	const result = await executor({
		reviewer: "anthropic/claude-sonnet-4-5:low",
		originalProblemPath: "problem.txt",
		goal: "goal summary",
		scope: "scope",
		claims: ["claim"],
		versionLabel: "v1",
		snapshotDir: snapshot,
		materials: [
			{ path: "problem.txt", snapshotPath: "problem.txt", purpose: "original", size: 1, mtimeMs: 1 },
		],
	});
	assert.equal(result.rawReport, "visible review");
	assert.equal(result.summary, "visible review");
	assert.doesNotMatch(result.rawReport, /private/);
	assert.match(prompt, /第一步必须先用 snapshot_read 完整读取原始问题文件：problem\.txt/);
	assert.equal(disposed, true);
});

test("Pi review executor rejects a final error instead of reusing earlier assistant text", async () => {
	const { snapshot } = await fixture();
	const runtime = await ModelRuntime.create({ credentials: new InMemoryCredentialStore(), allowModelNetwork: false });
	let snapshotRead: any;
	const fakeSession = {
		getActiveToolNames: () => ["snapshot_read", "snapshot_list"],
		prompt: async () => {
			await snapshotRead.execute("read-original", { path: "problem.txt" }, undefined, undefined, undefined);
		},
		messages: [
			{ role: "assistant", content: [{ type: "text", text: "I will review" }], stopReason: "stop" },
			{ role: "assistant", content: [{ type: "text", text: "partial" }], stopReason: "error", errorMessage: "provider failed" },
		],
		abort: async () => {},
		dispose: () => {},
	};
	const executor = createPiReviewExecutor({
		modelRuntime: runtime,
		createSession: (async (options: any) => {
			snapshotRead = options.customTools[0];
			return { session: fakeSession, extensionsResult: {} };
		}) as any,
	});
	await assert.rejects(
		() => executor({
			reviewer: "anthropic/claude-sonnet-4-5:low",
			originalProblemPath: "problem.txt",
			goal: "goal",
			scope: "scope",
			claims: ["claim"],
			versionLabel: "v1",
			snapshotDir: snapshot,
			materials: [{ path: "problem.txt", snapshotPath: "problem.txt", purpose: "original", size: 1, mtimeMs: 1 }],
		}),
		/provider failed|did not complete normally/,
	);
});

test("Pi review executor rejects a report when the original problem was not actually read", async () => {
	const { snapshot } = await fixture();
	const runtime = await ModelRuntime.create({ credentials: new InMemoryCredentialStore(), allowModelNetwork: false });
	const fakeSession = {
		getActiveToolNames: () => ["snapshot_read", "snapshot_list"],
		prompt: async () => {},
		messages: [{ role: "assistant", content: [{ type: "text", text: "unsupported report" }], stopReason: "stop" }],
		abort: async () => {},
		dispose: () => {},
	};
	const executor = createPiReviewExecutor({
		modelRuntime: runtime,
		createSession: (async () => ({ session: fakeSession, extensionsResult: {} })) as any,
	});
	await assert.rejects(
		() => executor({
			reviewer: "anthropic/claude-sonnet-4-5:low",
			originalProblemPath: "problem.txt",
			goal: "goal",
			scope: "scope",
			claims: ["claim"],
			versionLabel: "v1",
			snapshotDir: snapshot,
			materials: [{ path: "problem.txt", snapshotPath: "problem.txt", purpose: "original", size: 1, mtimeMs: 1 }],
		}),
		/did not read the frozen original problem/,
	);
});

test("actual Pi SDK session exposes only snapshot_read and snapshot_list without prompting a model", async () => {
	const { snapshot } = await fixture();
	const modelRuntime = await ModelRuntime.create({ credentials: new InMemoryCredentialStore(), allowModelNetwork: false });
	const model = modelRuntime.getModel("anthropic", "claude-sonnet-4-5");
	assert.ok(model, "fixed Pi catalog should contain the test model descriptor");
	const resourceLoader = await createReviewResourceLoader(snapshot);
	const { tools } = createSnapshotTools(snapshot);
	const { session } = await createAgentSession({
		cwd: snapshot,
		model,
		modelRuntime,
		noTools: "builtin",
		tools: ["snapshot_read", "snapshot_list"],
		customTools: tools,
		resourceLoader,
		sessionManager: SessionManager.inMemory(snapshot),
	});
	try {
		assert.deepEqual([...session.getActiveToolNames()].sort(), ["snapshot_list", "snapshot_read"]);
		assert.deepEqual(resourceLoader.getAgentsFiles().agentsFiles, []);
		assert.deepEqual(resourceLoader.getSkills().skills, []);
		assert.deepEqual(resourceLoader.getPrompts().prompts, []);
		assert.deepEqual(resourceLoader.getExtensions().extensions, []);
		assert.equal(session.messages.length, 0, "no model prompt was sent");
	} finally {
		session.dispose();
	}
});

/** Offline-only projected model-visible prompt. No runner, model, or network imports. */
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { SharedBudget } from "../../src/experiments/budget.ts";
import { createCpuResponseEnvironment } from "../../src/experiments/local-environment.ts";
import { GenerationStore } from "../../src/improvement/generation.ts";
import { decisionPrompt, improverSystemPrompt } from "../../src/improvement/policy-host.ts";
import { validateResearchPlan } from "../../src/improvement/research-types.ts";

const runDir = path.join(process.cwd(), ".agent", "private", "l5-pilot-first");
const readJson = async (file: string) => JSON.parse(await readFile(file, "utf8"));
const plan = validateResearchPlan(await readJson(path.join(runDir, "research-plan-i-one.json")));
const frozen = await readJson(path.join(runDir, "development-cases.json"));
const prior = await readJson(path.join(runDir, "visible-feedback.json"));
const journal = (await readFile(path.join(runDir, "observations.jsonl"), "utf8")).trim().split("\n").map(JSON.parse);
const store = new GenerationStore(runDir);
const active = await store.active();
if (!active || active.pointer.provenance !== "human-seed" || frozen.cases?.length !== 1 || frozen.cases[0].id !== prior.caseId)
	throw new Error("prepared human-seed or frozen development case differs");
const improver = await store.readStrategy(active.bundle.improverVersionId);
const previewRunId = "offline-preview-only";
const budget = new SharedBudget(previewRunId, plan.budget);
const env = createCpuResponseEnvironment(frozen.cases[0], budget);
const start = await env.development.prepare("offline-preview-seed");
const task = env.development.publicTask(start);
const initialId = `outer-initial-${task.caseId}`;
const initial = { version: 1, id: initialId, startId: initialId, actionId: "prepare", status: "observed", observations: task.initialObservations,
	remainingProbeCalls: task.maxProbeCalls, checks: [], evidence: [{ storeId: `method-research:${previewRunId}`, id: initialId, version: "1" }], visibility: "development" };
const past = prior.developmentFeedback.map((partial: Record<string, unknown>) => {
	const ref = (partial.evidence as Array<{ id: string; storeId: string; version: string }>)[0];
	const line = journal[Number(ref.id) - 1];
	if (!line || line.index !== Number(ref.id) || line.feedback.id !== partial.id ||
		JSON.stringify(line.feedback.observations) !== JSON.stringify(partial.observations) || ref.storeId !== "l5-pilot-first/observations.jsonl")
		throw new Error("development feedback does not resolve to frozen journal");
	const saved = line.feedback;
	return { version: 1, id: saved.id, startId: saved.startId, actionId: saved.actionId, status: saved.status,
		observations: saved.observations.map((o: { x: number; y: number; xUnit: string; yUnit: string; source: string }) =>
			({ x: o.x, y: o.y, xUnit: o.xUnit, yUnit: o.yUnit, source: o.source })),
		remainingProbeCalls: saved.remainingProbeCalls, checks: [], evidence: [ref], visibility: "development" };
});
const view = { version: 1, target: plan.target, current: { bundleId: active.bundle.bundleId, executorVersionId: active.bundle.executorVersionId,
	improverVersionId: active.bundle.improverVersionId }, task, feedback: [initial, ...past].slice(-plan.maxFeedbackItems),
	historicalFeedbackIds: past.map((f: { id: string }) => f.id), experience: { markdown: "", refs: [] }, candidates: [], budget: budget.status() };
const systemPrompt = improverSystemPrompt(improver.artifact as never);
const userMessage = decisionPrompt(view as never);
const payload = { previewOnly: true, reason: "runtime IDs are fresh; this is the local model-facing projection before any network request",
	modelRole: "improver", model: active.bundle.modelConfig.improver, systemPrompt, userMessage,
	lengths: { systemCharacters: systemPrompt.length, userCharacters: userMessage.length, totalCharacters: systemPrompt.length + userMessage.length,
		systemBytes: Buffer.byteLength(systemPrompt, "utf8"), userBytes: Buffer.byteLength(userMessage, "utf8") } };
const file = path.join(runDir, "i-one-model-visible-preview.json");
await writeFile(file, `${JSON.stringify(payload, null, 2)}\n`, { mode: 0o600 });
process.stdout.write(`${JSON.stringify({ previewPath: file, lengths: payload.lengths,
	viewFields: Object.keys(view), taskFields: Object.keys(task), feedbackCount: view.feedback.length, historicalFeedbackCount: past.length,
	containsPrivateTruthKey: systemPrompt.includes("truthHypothesisId") || userMessage.includes("truthHypothesisId"),
	containsProtectedEvaluator: systemPrompt.includes("protectedEvaluator") || userMessage.includes("protectedEvaluator"),
	containsCredentialName: systemPrompt.includes("DEEPSEEK_API_KEY") || userMessage.includes("DEEPSEEK_API_KEY") })}\n`);

/** Private, one-shot, billable L5 development pilot. Never part of npm test. */
import { appendFile, mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { ModelRuntime } from "@earendil-works/pi-coding-agent";
import { SharedBudget } from "../../src/experiments/budget.ts";
import { createCpuResponseEnvironment, type CpuResponseCase } from "../../src/experiments/local-environment.ts";
import { runExecutorEpisode } from "../../src/improvement/executor-eval.ts";
import { PiSessionRunner } from "../../src/runner/pi.ts";

const root = process.cwd();
const privateRoot = path.join(root, ".agent", "private");
const runDir = path.join(privateRoot, "l5-pilot-first");
const model = "deepseek/deepseek-flash:low";
const stamp = new Date().toISOString();

// mkdir without recursive is an intentional one-shot guard against resetting the call budget.
await mkdir(runDir, { mode: 0o700 });
await mkdir(path.join(runDir, "profile"), { mode: 0o700 });
await mkdir(path.join(runDir, "sessions"), { mode: 0o700 });
await writeFile(path.join(runDir, "research.config.json"), `${JSON.stringify({ roles: { research: model } }, null, 2)}\n`, { mode: 0o600 });

const secret = JSON.parse(await readFile(path.join(privateRoot, "deepseek", "credentials.json"), "utf8")) as { apiKey?: unknown };
if (typeof secret.apiKey !== "string" || !secret.apiKey.startsWith("sk-")) throw new Error("private DeepSeek credential unavailable");
process.env.PI_CODING_AGENT_DIR = path.join(runDir, "profile");
process.env.DEEPSEEK_API_KEY = secret.apiKey;

const runtime = await ModelRuntime.create({ modelsPath: null, refreshOnCreate: false, allowModelNetwork: false });
const selected = runtime.getModel("deepseek", "deepseek-flash");
if (!selected || selected.provider !== "deepseek" || selected.api !== "openai-completions") throw new Error("unexpected model resolution");
const runner = new PiSessionRunner({ modelRuntime: runtime });
const rootLimits = { maxProviderCalls: 12, maxInputTokens: 60_000, maxOutputTokens: 20_000, maxSdkEstimatedCost: 5, maxProbeCalls: 16, maxCpuMillis: 10_000, maxWallMillis: 300_000 };
const budget = new SharedBudget("l5-batch-2026-09-23", rootLimits);
const lease = budget.createLease(budget.root, { ...rootLimits, maxProviderCalls: 3, maxInputTokens: 30_000, maxOutputTokens: 6_144, maxProbeCalls: 2, maxWallMillis: 210_000 });
const caseSpec: CpuResponseCase = {
	id: "generic-response-identification-1", version: 1, truthHypothesisId: "linear-response",
	hypotheses: [
		{ id: "linear-response", formula: { kind: "affine", slope: 2, intercept: 2 } },
		{ id: "curved-response", formula: { kind: "quadratic", coefficient: 2, intercept: 2 } },
	],
	initialX: [0], allowedProbeX: [1, 2], maxProbeCalls: 2, tolerance: 0.001, units: { x: "arbitrary-input", y: "arbitrary-output" },
};
await writeFile(path.join(runDir, "private-case.json"), `${JSON.stringify(caseSpec, null, 2)}\n`, { mode: 0o600 });
const observationPath = path.join(runDir, "observations.jsonl");
let observations = 0;
const env = createCpuResponseEnvironment(caseSpec, budget, {
	persistObservation: async (record) => {
		const line = JSON.stringify({ version: 1, index: ++observations, at: new Date().toISOString(), ...record });
		if (Buffer.byteLength(line, "utf8") > 4096) throw new Error("observation record exceeds private trace cap");
		await appendFile(observationPath, `${line}\n`, { mode: 0o600 });
		return { storeId: "l5-pilot-first/observations.jsonl", id: String(observations), version: "1" };
	},
});
const health = await env.development.healthCheck();
await writeFile(path.join(runDir, "health.json"), `${JSON.stringify(health, null, 2)}\n`, { mode: 0o600 });
if (!health.usable) throw new Error("CPU environment health check failed");
const start = await env.development.prepare("pilot-fixed-seed");
const rssBefore = process.memoryUsage().rss;
const episode = await runExecutorEpisode({
	development: env.development, start,
	method: { version: 1, kind: "cpu-numerical-prompt", body: "Use the observations to decide which response mechanism is supported. You may request an allowed measurement when it would help distinguish hypotheses. Submit a hypothesis only when the observations justify it; otherwise explain uncertainty through the stop action. Return one JSON action per turn." },
	methodVersionId: "human-seed-h0", runner, model, persistDir: path.join(runDir, "sessions"), budget, lease, timeoutMs: 60_000, maxActions: 3,
});
const protectedResult = episode.status === "submitted" && episode.selectedHypothesisId
	? await env.protectedEvaluator.evaluate(start, episode.selectedHypothesisId)
	: episode.status === "stopped" ? await env.protectedEvaluator.evaluateStop(start) : undefined;
const files = await readdir(path.join(runDir, "sessions"));
let sessionBytes = 0;
for (const file of files) sessionBytes += (await stat(path.join(runDir, "sessions", file))).size;
const report = {
	version: 1, startedAt: stamp, endedAt: new Date().toISOString(), model, noTools: true,
	callCapThisPilot: 3, fullBatchCap: { providerCalls: 12, inputTokens: 60_000, outputTokens: 20_000 },
	health, episode, protectedResult,
	rootBudget: budget.status(), childBudget: budget.status(lease),
	resource: { pid: process.pid, rssBefore, rssAfter: process.memoryUsage().rss, sessionFiles: files.length, sessionBytes },
};
await writeFile(path.join(runDir, "report.json"), `${JSON.stringify(report, null, 2)}\n`, { mode: 0o600 });
process.stdout.write(`${JSON.stringify({ pilot: "l5-pilot-first", callsReserved: report.rootBudget.committed.providerCalls, reportedInput: report.rootBudget.committed.inputTokens, reportedOutput: report.rootBudget.committed.outputTokens, settlement: report.rootBudget.settlement, episodeStatus: episode.status, actionKinds: episode.feedback.map((f) => f.status), protectedStatus: protectedResult?.status, healthUsable: health.usable, sessionBytes, rssDelta: report.resource.rssAfter - rssBefore })}\n`);

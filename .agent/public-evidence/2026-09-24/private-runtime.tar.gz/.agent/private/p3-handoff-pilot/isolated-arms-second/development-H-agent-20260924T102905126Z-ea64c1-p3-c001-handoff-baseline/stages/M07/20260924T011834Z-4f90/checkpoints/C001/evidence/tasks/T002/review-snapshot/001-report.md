已完成 T002 最小路径修正任务。

## 实际动作
1. 读取输入副本 `inputs/001-fp8-stage-sqnr.md`、`inputs/002-fp8_stage_sim.py`。
2. 用 `cp -p` 把两份产物原样搬到 T002 work 根：
   - `inputs/001-fp8-stage-sqnr.md` → `./fp8-stage-sqnr.md`
   - `inputs/002-fp8_stage_sim.py` → `./fp8_stage_sim.py`
3. 复算 sha256 / 字节数并断言与输入副本一致。
4. 写 `work/report.md` 说明 relocation、命令与 sha256。
5. 对产物 grep `token|secret|sessionToken|api[_-]?key`：命中均为正文术语（如 "per-token"）与免责声明文字，无实际凭据、无提交源码正文。

## 产物（本任务 work 根）
- `fp8-stage-sqnr.md` — 12884 B，sha256 `98f976ad…5e630c`（与输入副本相同）
- `fp8_stage_sim.py` — 17952 B，sha256 `f2e4cf5f…b0709b6`（与输入副本相同）
- `report.md`

## 验证（实测）
`shasum -a 256` 四文件两两一致；`diff -q` 两份产物与输入副本均无差异（输出 `ALL IDENTICAL`）。断言成立：内容未改。

## 未执行项与限制
- 未运行 `fp8_stage_sim.py`、未编译、未 GPU、未提交、未自测、未创建 custom test、未调用 `Web.submit`、未联网。
- 未修改工作区外文件；所有写盘均在 T002 `work` 目录内。
- 未对产物技术结论再评估，其代表性以原文为准。
- 本机无 nvcc（沿用既有事实，本任务不需要编译）。

会话返回不代表成果被主 Agent 接受；以上为实际动作与读数。
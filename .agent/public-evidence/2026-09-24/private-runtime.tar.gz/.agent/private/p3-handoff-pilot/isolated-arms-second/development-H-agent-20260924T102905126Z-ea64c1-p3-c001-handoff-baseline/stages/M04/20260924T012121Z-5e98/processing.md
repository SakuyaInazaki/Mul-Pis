## 处理结果（文字）

### 1. 本轮意见/材料的定位

本轮不是针对既有结论的质询式评审，而是一份 M07 开发 checkpoint（`C001`，run `20260924T011834Z-4f90`）的反馈包。其中实际交接了两项任务：

- **T001**（execute，状态 `returned`，会话报告未产生）：CPU numpy 数值模拟——把单趟驻留缓冲里的残差 x 从 BF16 改为 e4m3(FP8) 暂存后对 mHC 输出 SQNR 的影响，判断该 smem 减半路线能否过 28 dB 门。
- **T002**（execute，状态 `accepted`）：最小路径修正——把 T001 误写到嵌套目录（`T001/work/work/`）的两份产物原样搬到 T002 work 根，报出 sha256 并断言与输入副本一致。

我读到的实际材料：`manifest.json`、`goal.json`（本会话用工具读取），以及 pack 内联的 `evidence/tasks/T002/review-snapshot/{001-report,002-fp8-stage-sqnr,003-fp8_stage_sim}` 全文。科学内容主要在前两者之外的 002（报告）与 003（脚本）。

### 2. 科学内容评估（区分实测、推导与主张）

**T001 模拟的方法学核对（我实际核对了报告正文与脚本）**：
- 参考前向实现与题面语义逐点对应（BF16 投影→BF16 存→FP32 RMS/仿射→sigmoid/sinkhorn→u→W1/W2 低秩 MLP→mix 残差混合→post 写回），含各 BF16 舍入点，合理。
- e4m3 位表构造（0..0x7E，剔 0x7F=NaN，最大 448，含次正规）与最近邻/RNE 实现自洽；报告给出的单元校验（`q(0.7)=0.6875`、`q(100)=96`、`q(448)=448`；`bf16(0.1)=0.10009765625`）一致。
- 信息论下界推导我独立复算：e4m3 mantissa 3 位 ⇒ 相对 ulp ∈ (2⁻⁴, 2⁻³]，均匀舍入 RMS ∈ (2⁻⁴/√12, 2⁻³/√12) = (0.018, 0.036]，几何均值 ≈0.0255 ⇒ ≈31.7 dB。**与报告一致**，故主结果的 ~31.3–31.8 dB 确实逼近“只改 x 暂存”的精度量级上限，不是可随意调参提升的量。

**结论性读数（合成数据，非平台实测）**：
- `both`（term_res+layer_input 用 fp8，投影仍 bf16）31.324–31.784 dB，min 31.324，余 ≈3.32 dB；
- `all`（三处都用 fp8，更贴近真实单趟驻留读数口径）30.411–30.911 dB，余 ≈2.41 dB；
- 误差主导在 term_res 分支；幅度带敏感（raw e4m3 仅 `s∈[0.03,100]` 过门，`s=0.01`→24.98 dB，`s≥300`→截断 3–13 dB）；压力分布（0.1%元素×2000）raw = 1.555 dB，加 per-tensor/per-token 缩放可回 30–43 dB。

**我的采纳判定**：采纳为**风险输入**（candidate / exploratory_only）。明确不采纳为：(i)“平台会过门”的证据；(ii) 对该 smem/panel 路线可行或不可行的判定——报告 §6 自限“只回答数值是否够用”，我认同该限定。工作假设层面的推论：**无缩放的 raw e4m3 名义过门但余量薄且不稳健**，且该余量依赖未知的真实残差分布。

**对既有认识的关系**：这条内容给 K031@2（n4/C2560 单趟驻留 smem 超预算）与 Q001@3（替代版图未评估）补入了一个“数值可行性”侧面——即“若靠 fp8 把 x 减半”这条路，数值上仅勉强且脆弱，不足以消解版图问题；不改变 D001@1 的 working_assumption（只是又一条杠杆被评估为弱）。

### 3. 关键解释（为什么这样定，而不只“接受第几条”）

- 报告自陈是 **CPU 合成模拟**、形状为 (64,4,256)/(64,2,256)、参数与分布为合成假设（fn/scale/base 分布题面未给）。因此“28 dB 门通过/不通过”在本轮只是**条件命题**，不是对真实测试点的裁定。我把条件与作用域显式写进记录。
- T001 状态为 `returned` 且会话报告未产生；其产物仅经 T002 relocation 进入 evidence。我把“产物落错目录/relocation”记为**执行事实**，不把它读成“科学内容被否”，也不把 `checks passed` 读成“数值/结论已获证明”。
- 我未编译、未跑 GPU、未复算 sha256、未读 T001 原始 `work/work/` 目录（不在清单内）；报告与脚本正文是 pack 完整内联的评审快照，我据此核对正文，但**不声称独立重算了哈希或核对了原始目录**。

### 4. 未采纳 / 未决 / 缺口

- **未决（交回相应环节）**：真实残差分布未知（题面仅说“按真实模型典型分布生成”）；per-tensor/per-token 缩放的 kernel 实现成本（amax 归约、缩放因子存储、量化/反量化指令、对逐字节确定性与时间的影响）未评估；未在真实形状与平台正确性门下实测。消解需平台侧残差幅度证据或含缩放 fp8 路径的原型实现+平台 SQNR 实测（本机无 nvcc）。
- **不采纳**：把该模拟当作性能路线成立或失败的裁决；把 `returned` 当作科学否决。

### 5. 实际更新与限制说明

- 本轮新增：一条 fp8 暂存 SQNR 模拟记录、一条其未决问题、一条 T001/T002 执行事实记录；与 K031@2、Q001@3、D001@1 建立 supports 关系。
- 无既有记录被修订、限定或撤回；Q001 仍开放（本轮不构成消解）。
- 我**没有**任何自动合入/隔离机制可用：以上仅为提案，需由合入环节实际执行；未做即未做，不声称已完成。合入后 K031/K035/Q001 的既有 `needs_recheck` 限制保持不变。

```knowledge-proposals
[
  {
    "op": "create",
    "type": "K",
    "title": "e4m3 暂存 residual x 对 mHC 输出 SQNR 的 CPU 合成模拟（条件性）",
    "body": "对象：把单趟驻留缓冲中的 residual x 由 BF16 改为 e4m3(FP8) 量化-反量化暂存后，对 mHC 输出相对题面参考的 SQNR 影响，用以判断该 smem 减半路线对 28 dB 门的余量。\n\n依据：T001@4f90 的 CPU numpy 合成模拟（脚本 work/fp8_stage_sim.py、报告 work/fp8-stage-sqnr.md；经 T002 原样 relocation 进入评审快照；本会话核对了报告正文与脚本，未编译、未实测）。形状 (T,n,C)=(64,4,256) 与 (64,2,256)；3 种合成残差分布；fn/mlp_w1/mlp_w2 取合成分布假设、scale=1、base=0。\n\n结果（全部为合成数据）：\n- both（term_res+layer_input 用 fp8，系数投影仍 bf16）：31.324–31.784 dB，min 31.324，余量 ≈3.32 dB。\n- all（投影+term_res+layer_input 三处都用 fp8，更贴近真实单趟驻留读数口径）：30.411–30.911 dB，余量 ≈2.41 dB。\n- 误差主导在 term_res 分支；layer_input 与 projected 单改影响小。\n- 幅度敏感（raw e4m3 非尺度不变）：仅 N(0,1)·s 的 s∈[0.03,100] 过门；s=0.01→24.98 dB（下溢）；s≥300→13.3→3.4 dB（截断）。\n- 压力分布（主体 N(0,1)+0.1% 元素×2000，0.085% 超 448）：raw=1.555 dB；per-tensor 30.22 dB；per-token 43.52 dB。\n- 信息论估计 e4m3 相对 RMS≈0.026→≈31.7 dB，与主结果一致，为‘只改 x 暂存’的精度上限量级；本会话独立复算该下界成立。\n\n条件与限度：\n(a) CPU 合成模拟，非平台实测；未编译、无 GPU、未提交/自测。\n(b) 分布与参数为合成假设；题面仅说‘按真实模型典型分布生成’，真实残差分布未知，故过门/不过门条件对真实测试点不作保证。\n(c) 小形状，非题面真实形状（C∈{1280..8192}, T∈{4096..32768}）。\n(d) per-tensor/per-token 缩放的 kernel 实现成本（amax、缩放因子存储、量化/反量化开销及对逐字节确定性与时间的影响）未评估。\n(e) 不代表平台会过门，也不构成对 smem/panel 路线可行性的判定（报告 §6 自限，认同）。\n\n用法：作为 e4m3 暂存路线的风险输入（candidate / exploratory_only）。条件性判断：‘无缩放的 raw e4m3 名义过门但余量薄（2.4–3.3 dB）且不稳健，且依赖未知的真实残差分布’。",
    "refs": [
      {"rel": "supports", "target": "K031@2"},
      {"rel": "supports", "target": "Q001@3"},
      {"rel": "supports", "target": "D001@1"}
    ],
    "evidenceStatus": "T001@4f90 CPU 合成模拟（execute，status=returned）；报告与脚本经 T002 relocation 后以评审快照完整内联；本会话核对报告正文与脚本；未编译、未实测；未独立重算 sha256",
    "usageDecision": "candidate",
    "reason": "为‘靠 fp8 把 x 减半以缓解 n4/C2560 smem 超预算’这一候选路线提供数值可行性输入；属条件性、合成数据结果，故 candidate/exploratory_only。",
    "handle": "$fp8"
  },
  {
    "op": "create",
    "type": "Q",
    "title": "e4m3 暂存 residual x 路线的真实分布稳健性与缩放实现成本未评估",
    "body": "问题：e4m3 暂存 residual x 路线的真实可行性与实现代价未决。已暴露缺口（基于本轮 fp8 暂存 SQNR 模拟记录）：\n(i) 真实测试点残差分布未知——‘可用带’[0.03,100] 与‘无超 448 元素’是否成立，无法从 CPU 合成模拟断言；\n(ii) per-tensor/per-token 缩放（可把最坏 1.6 dB 拉回 30–43 dB）在 kernel 内的实现成本与副作用（amax 归约、缩放因子存储、量化/反量化指令、对逐字节确定性与正式运行时间的影响）未评估；\n(iii) 未在真实形状与平台正确性门下实测。\n消解需要：平台侧/真实残差幅度证据，或对含缩放 fp8 路径的原型实现与平台 SQNR 实测（本机无 nvcc，需 GPU/平台）。未消解前，不得据此断言 fp8 暂存路线可行或不可行。",
    "refs": [
      {"rel": "supports", "target": "Q001@3"}
    ],
    "evidenceStatus": "基于 T001@4f90 合成模拟报告与其自身列出的未验证项（报告 §7/§8）；本会话核对报告正文",
    "usageDecision": "candidate",
    "reason": "把 fp8 路线的未决项显式登记，避免用合成模拟结果冒充真实测试点的裁定。",
    "handle": "$qe4m3"
  },
  {
    "op": "create",
    "type": "E",
    "title": "T001@4f90 产物误写嵌套目录，T002 原样 relocation 保持内容不变（执行事实）",
    "body": "执行事实：T001@4f90（CPU fp8 模拟，execute）状态 returned、会话报告未产生；其两份产物被写到嵌套路径（相对 cwd 的 work/ ⇒ T001/work/work/），manifest 中 T001 的 workDir 与 expectedOutputPaths 为空。T002@4f90（execute，status=accepted）以 cp -p 从 inputs 副本把两份产物原样复制到 T002 work 根，报出 sha256：fp8-stage-sqnr.md 12884 B 98f976ad…5e630c、fp8_stage_sim.py 17952 B f2e4cf5f…b0709b6，并以 diff -q 判定与输入副本一致；三条内容检查 passed。\n限度：本会话读取了 manifest.json 与反馈包内联的评审快照（报告与脚本正文完整内联），未独立重算 sha256，也未核对 T001 原始 work/work/ 目录（不在清单内）。解释（非平台结论）：‘returned’为流程状态，不等同科学内容被否；‘checks passed’也不等于数值/结论已获证明。",
    "refs": [
      {"rel": "supports", "target": "$fp8"}
    ],
    "evidenceStatus": "本轮 manifest.json 与 T002 报告/工具日志 + 内联快照；本会话读取 manifest 与内联快照；未独立重算哈希",
    "usageDecision": "candidate",
    "reason": "记录本轮真实执行行为（产物落错目录与 relocation），以区分产物位置问题与科学内容，符合既往同类执行事实的记录先例。",
    "handle": "$exe4f90"
  }
]
```

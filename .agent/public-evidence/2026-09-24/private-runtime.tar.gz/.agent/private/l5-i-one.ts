/** Private, one-shot L5 I-development handoff. Never part of npm test. */
import { existsSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { ModelRuntime } from "@earendil-works/pi-coding-agent";
import { ResearchImprovementService } from "../../src/improvement/research-service.ts";
import { validateResearchPlan } from "../../src/improvement/research-types.ts";
import { FakeSessionRunner } from "../../src/runner/fake.ts";
import { PiSessionRunner } from "../../src/runner/pi.ts";

const mode = process.argv[2];
if (mode !== "prepare" && mode !== "run") throw new Error("expected prepare or run");
const privateRoot = path.join(process.cwd(), ".agent", "private");
const runDir = path.join(privateRoot, "l5-pilot-first");
const configPath = path.join(runDir, "research.config.json");
const preparedPath = path.join(runDir, "i-one-prepared.json");
const attemptPath = path.join(runDir, "i-one-attempt.json");
const ledgerPath = path.join(privateRoot, "l5-batch-ledger.json");
const readJson = async (file: string) => JSON.parse(await readFile(file, "utf8"));
const safeWrite = async (file: string, value: unknown, exclusive = false) => writeFile(file, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600, flag: exclusive ? "wx" : "w" });
const neutralExecutor = "Use the observations to decide which response mechanism is supported. You may request an allowed measurement when it would help distinguish hypotheses. Submit a hypothesis only when the observations justify it; otherwise explain uncertainty through the stop action. Return one JSON action per turn.";
const neutralImprover = "Use the visible observations, prior development feedback, and stated limits to choose one justified next diagnostic action. Propose a bounded method change only if the evidence suggests a testable improvement; describe what result would falsify it. Acknowledge uncertainty when the available evidence is insufficient. Return one JSON action.";
const plan = validateResearchPlan({
	version: 1, experimentKind: "meta-improvement", target: "improver",
	developmentCaseSetPath: "development-cases.json", priorDevelopmentFeedbackPath: "visible-feedback.json",
	maxDecisions: 1, maxCandidates: 1, admissionRepetitions: 2, maxFeedbackItems: 8, perPromptTimeoutMs: 60_000, perPromptMaxOutputTokens: 4_096,
	budget: { maxProviderCalls: 1, maxInputTokens: 25_000, maxOutputTokens: 4_096, maxSdkEstimatedCost: 0.2,
		maxProbeCalls: 1, maxCpuMillis: 5_000, maxWallMillis: 120_000 },
	experienceRefs: [], experienceMaxRecords: 0, experienceMaxChars: 0,
});

if (mode === "prepare") {
	if (existsSync(preparedPath) || existsSync(attemptPath)) throw new Error("I handoff has already been prepared or attempted");
	const config = await readJson(configPath);
	if (config.roles?.research !== "deepseek/deepseek-flash:low" || config.roles?.improver !== undefined) throw new Error("unexpected pilot model config");
	const frozenCase = await readJson(path.join(runDir, "private-case.json"));
	const visible = await readJson(path.join(runDir, "visible-feedback.json"));
	const ledger = await readJson(ledgerPath);
	if (frozenCase.id !== visible.caseId || visible.developmentFeedback?.length !== 2 || ledger.segments?.length !== 1 ||
		ledger.remaining?.providerRequests !== 10 || ledger.remaining?.inputTokens !== 58902 || ledger.remaining?.outputTokens !== 19550)
		throw new Error("frozen case, visible feedback, or carried global ledger differs from first segment");
	config.roles.improver = config.roles.research;
	await safeWrite(configPath, config);
	await safeWrite(path.join(runDir, "development-cases.json"), { version: 1, split: "development", cases: [frozenCase] });
	await safeWrite(path.join(runDir, "research-plan-i-one.json"), plan);
	const service = new ResearchImprovementService({ workspaceRoot: runDir, runner: new FakeSessionRunner(() => { throw new Error("offline bootstrap must not prompt"); }) });
	const bundle = await service.bootstrap({ version: 1,
		executor: { version: 1, kind: "cpu-numerical-prompt", body: neutralExecutor },
		improver: { version: 1, kind: "diagnostic-improver-prompt", body: neutralImprover },
		applicability: ["cpu-response-identification"] });
	await safeWrite(preparedPath, { version: 1, source: "human-seed", baselineBundleId: bundle.bundleId,
		frozenCaseId: frozenCase.id, priorFeedbackCount: visible.developmentFeedback.length, planFile: "research-plan-i-one.json", noAdmission: true }, true);
	process.stdout.write(`${JSON.stringify({ phase: "prepared", source: "human-seed", priorFeedbackCount: visible.developmentFeedback.length,
		modelRole: "improver", oneCallCap: plan.budget.maxProviderCalls, outputCap: plan.budget.maxOutputTokens, noAdmission: true })}\n`);
} else {
	if (!existsSync(preparedPath)) throw new Error("I handoff is not prepared");
	const savedPlan = await readJson(path.join(runDir, "research-plan-i-one.json"));
	if (JSON.stringify(savedPlan) !== JSON.stringify(plan)) throw new Error("prepared plan changed");
	const ledger = await readJson(ledgerPath);
	if (ledger.segments?.length !== 1 || ledger.remaining?.providerRequests !== 10 || ledger.remaining?.inputTokens !== 58902 || ledger.remaining?.outputTokens !== 19550)
		throw new Error("global ledger changed; refuse a new paid attempt");
	await safeWrite(attemptPath, { version: 1, at: new Date().toISOString(), status: "started", maxProviderCalls: 1 }, true);
	const secret = await readJson(path.join(privateRoot, "deepseek", "credentials.json"));
	if (typeof secret.apiKey !== "string" || !secret.apiKey.startsWith("sk-")) throw new Error("private DeepSeek credential unavailable");
	process.env.PI_CODING_AGENT_DIR = path.join(runDir, "profile");
	process.env.DEEPSEEK_API_KEY = secret.apiKey;
	const runtime = await ModelRuntime.create({ modelsPath: null, refreshOnCreate: false, allowModelNetwork: false });
	const model = runtime.getModel("deepseek", "deepseek-flash");
	if (!model || model.provider !== "deepseek" || model.api !== "openai-completions") throw new Error("unexpected model resolution");
	const runner = new PiSessionRunner({ modelRuntime: runtime });
	const service = new ResearchImprovementService({ workspaceRoot: runDir, runner });
	const result = await service.run(plan);
	const budget = result.budgetAtEnd as { committed?: { providerCalls?: number; inputTokens?: number; outputTokens?: number; sdkEstimatedCost?: number }; settlement?: string };
	const committed = budget?.committed;
	if (!committed || !Number.isSafeInteger(committed.providerCalls) || committed.providerCalls! > 1 || committed.providerCalls! < 0 ||
		!Number.isFinite(committed.inputTokens) || !Number.isFinite(committed.outputTokens) || !Number.isFinite(committed.sdkEstimatedCost))
		throw new Error("run returned invalid budget; inspect private records before any further request");
	const segment = { runId: result.runId, providerRequests: committed.providerCalls, inputTokens: committed.inputTokens,
		outputTokens: committed.outputTokens, sdkEstimatedCost: committed.sdkEstimatedCost, settlement: budget.settlement,
		researchRunPath: path.relative(privateRoot, path.join(runDir, ".agent", "improvement", "research", "runs", result.runId, "run.json")) };
	ledger.segments.push(segment);
	ledger.remaining = { providerRequests: ledger.remaining.providerRequests - segment.providerRequests,
		inputTokens: ledger.remaining.inputTokens - segment.inputTokens, outputTokens: ledger.remaining.outputTokens - segment.outputTokens };
	ledger.blocked = budget.settlement !== "settled" || ledger.remaining.providerRequests < 0 || ledger.remaining.inputTokens < 0 || ledger.remaining.outputTokens < 0;
	await safeWrite(ledgerPath, ledger);
	await safeWrite(attemptPath, { version: 1, at: new Date().toISOString(), status: "recorded", runId: result.runId,
		providerRequests: segment.providerRequests, settlement: segment.settlement });
	process.stdout.write(`${JSON.stringify({ phase: "completed", runId: result.runId, runStatus: result.status, decisionCount: result.decisions.length,
		visibleActionKinds: result.decisions.map((d) => d.action?.kind ?? "unparsed"), candidateCount: result.candidates.length,
		selectedCandidate: !!result.selectedCandidateId, providerRequests: segment.providerRequests, inputTokens: segment.inputTokens,
		outputTokens: segment.outputTokens, sdkEstimatedCost: segment.sdkEstimatedCost, settlement: segment.settlement,
		globalRemaining: ledger.remaining, blocked: ledger.blocked })}\n`);
}

/**
 * Source-rule reproductions for Mul-Pis a8facf5995d07da215bead2ce521088bd560e713.
 * No provider, network, process signals or workspace mutations.
 * This is NOT the project's integration test suite.
 * Original conditions copied from src/pi/service.ts and scripts/workflow-control.ts.
 */
import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';

function originalStallRule({ checkMs, timeoutMs, ticks }) {
  const TIMER_SUSPEND_GAP_MS = 5_000;
  let lastProgressAt = 0;
  let lastStallCheckAt = 0;
  let progressMarker = 0;
  let comparisons = 0;
  let stoppedAt;
  for (let tick = 1; tick <= ticks; tick++) {
    const now = tick * checkMs;
    // Mirrors the current scheduled callback. No transcript/tool-log growth.
    const gap = now - lastStallCheckAt;
    lastStallCheckAt = now;
    if (gap > TIMER_SUSPEND_GAP_MS) {
      lastProgressAt += gap;
      continue;
    }
    const current = 0;
    if (current === progressMarker) {
      comparisons++;
      if (now - lastProgressAt > timeoutMs) {
        stoppedAt = now;
        break;
      }
      continue;
    }
    progressMarker = current;
    lastProgressAt = now;
  }
  return { elapsedMs: ticks * checkMs, comparisons, stoppedAt: stoppedAt ?? null, lastProgressAt };
}

// Proposed accounting example: only a trusted, explicit pause shifts progress age.
// This is not a patch to the repository, nor a production clock implementation.
function explicitPauseRule({ checkMs, timeoutMs, ticks, pauseAt, resumeAt }) {
  let lastProgressAt = 0;
  for (let tick = 1; tick <= ticks; tick++) {
    const now = tick * checkMs;
    if (pauseAt !== undefined && now >= pauseAt && now < resumeAt) continue;
    if (resumeAt !== undefined && now === resumeAt) lastProgressAt += resumeAt - pauseAt;
    if (now - lastProgressAt >= timeoutMs) return now;
  }
  return null;
}

const results = [];
const defaultResult = originalStallRule({ checkMs: 30_000, timeoutMs: 600_000, ticks: 40 });
assert.equal(defaultResult.stoppedAt, null);
assert.equal(defaultResult.comparisons, 0);
results.push({ test: 'current-default-stall-watchdog', expectation: 'Reproduce blind spot with default 30-second check interval', ...defaultResult, observedDefect: true });

const scaledTest = originalStallRule({ checkMs: 5, timeoutMs: 20, ticks: 20 });
assert.equal(scaledTest.stoppedAt, 25);
results.push({ test: 'current-millisecond-test-regime', ...scaledTest, explainsCoverageGap: true });

const proposed = explicitPauseRule({ checkMs: 30_000, timeoutMs: 600_000, ticks: 40 });
assert.equal(proposed, 600_000);
results.push({ test: 'proposed-explicit-pause-accounting-no-pause', stoppedAt: proposed, proposalOnly: true });

const paused = explicitPauseRule({ checkMs: 30_000, timeoutMs: 600_000, ticks: 40, pauseAt: 300_000, resumeAt: 420_000 });
assert.equal(paused, 720_000);
results.push({ test: 'proposed-explicit-pause-accounting-with-trusted-pause', stoppedAt: paused, proposalOnly: true });

// Current workflow-control.ts status expression: a stored pid replaces the one probed.
const command = 'status';
const pid = 42002;          // Synthetic freshly read run.pid.
const alive = true;         // Synthetic liveness result for pid 42002.
const state = { state: 'running', pid: 31001, updatedAt: 'synthetic' };
const displayed = { command, pid, alive, ...state };
assert.equal(displayed.pid, 31001);
assert.equal(displayed.alive, true);
results.push({ test: 'current-status-pid-overwrite', probedPid: pid, reportedPid: displayed.pid, reportedAlive: displayed.alive, observedDefect: true });

const report = { repositoryCommit: 'a8facf5995d07da215bead2ce521088bd560e713', scope: 'isolated source-rule reproduction; no project integration, real clocks, providers, network, signals, or RSI execution', testCasesPassed: 5, results };
console.log(JSON.stringify(report, null, 2));
if (process.argv[2]) writeFileSync(process.argv[2], JSON.stringify(report, null, 2) + '\n');

# Mul-Pis：先恢复科研执行，再闭合方法自改进

审查提交：`a8facf5995d07da215bead2ce521088bd560e713`。其源码更新来自父提交 `61469989dd2b35f8d819a06f7b0e6e25ab4097b2`。审查日期：2026-09-24。

## 0. 证据边界

本方案依据公开 `.agent/notes/2026-09-21-workflow-self-issues.md` 的 1—29 节、当前相关源码、用户提供的《The Last AI Built by Humans: Toward Genuine Recursive Self-Improvement》以及检索的一手研究。notes 是带证据位置的增量问题记录，不等于被引用的所有原始 JSONL 和私有 launcher 源码均已提供。

本次通过 GitHub 连接器读取源码；容器直接克隆因 DNS 不可用失败。未安装依赖、未运行整仓测试、未调用付费模型、未修改远程仓库。本包的五个用例是抽取源码判断规则的隔离复现与拟议逻辑对照，不是项目集成测试或 RSI 结果。

既有预算问题已经有修复：单次 token 配额被移除；元实验分支调用 closeLease；开发评价区分合理未知；I 收到剩余额度与上一步回执。不要重复实现这些功能，更不能用旧问题解释所有新故障。

## 1. 对这次故障的因果判断

### 1.1 记录直接支持的事故链

notes §29 记录了私有 launcher 把控制目录内历次 `main-*.jsonl` 都计入 64 MiB 硬上限。旧日志使新回合触限，launcher 停止进程，M07 以 blocked 归档；反馈生成又遇到 context.budget，剩下 control-facts-only 索引。另有已死亡 PID 留下的 merge lock 阻断 M04，以及监控增长日志的命令超时后清理整个 launcher/Pi 的实例。

这是生命周期、存储与恢复控制的问题。它不证明当前科学方法无效，也不能由 CPU 方法实验的 token 预算修复自动解决。

### 1.2 当前源码独立支持的缺陷

1. `src/pi/service.ts` 的 stallCheckMs 默认为 30000，而 TIMER_SUSPEND_GAP_MS 为 5000。每个正常检查间隔都会进入“暂停”分支并增加 lastProgressAt，导致默认 stall 检查永远跳过实际进展判断。总 prompt 超时是另一项保护，不能把这里描述为所有超时永远无效。
2. `scripts/workflow-control.ts` 的 status 合成顺序是 `{command,pid,alive,...state}`。旧 control.json 的 pid 可以覆盖刚刚进行存活检查的 pid，产生身份与存活状态错配。
3. 控制脚本向一个 PID 发信号，不保证控制全部子进程。notes 对 wrapper PID、orphan 与发现路径分裂有直接记录。
4. `knowledge/store.ts` 以独占文件实现 merge lock，超龄只报错，没有受控接管流程。`CURRENT` 写入先于 proposal result：崩溃后不能仅删锁再无条件重做 merge，必须识别已发布但回执未完成的窗口。
5. `M07Controller.interrupt()` 先令目标 finished/blocked，再产生反馈。它是归档，不是暂停后继续同一目标的协议。不要悄悄改变其旧语义；增加明确、版本化的 suspend/recover 路径。

### 1.3 不能推出的结论

不能从 notes 认定最新一轮一定运行了当前提交；需要运行时版本回执。不能认定私有 launcher 的内部实现在当前已修复；公开库未提供该代码。不能将 §19 的长等待称为永久死锁：§20 明确补充最终恢复。不能继续称 §13 的 provider 是无效旧模型：§14 已纠正。§17、§24 的修复和最新 expectedOutputs 占位符拒绝应保留回归测试，不重复列为未做功能。

## 2. 立即恢复的最小路径

### R0：停止扩大变更面

保留现场，不执行硬重置、不批量删 `.agent`、不改写旧目标为 fulfilled、不按文件年龄清锁、不杀所有同名 Pi 进程。对代码、工作区状态和外部操作分别保存恢复依据。

从原工作流的同类任务建立参考运行。参考包括仓库提交、Pi SDK 版本、实际 extension、launcher 配置、模型角色映射、输入版本与知识快照。不能随意指定某个旧 SHA 为“已验证稳定版”。

对工作区副本开展差分检查；旧知识限制继续生效。关闭的是未经验证的候选激活和自动演化，不是已经知道的安全/科学限制。

### R1：统一运行身份与控制入口

扩展既有 `scripts/workflow-control.ts`，不要再添加第四套 launcher。私有 launcher 必须实现相同注册契约或退出主运行链。

拟议 RunDescriptor：

```ts
interface RunDescriptorV1 {
  version: 1;
  instanceId: string;
  codeRevision: string;
  runtimeProfileId: string;
  workspaceId: string;
  goalId: string;
  attemptId: string;
  hostId: string;
  bootId?: string;
  pid: number;
  processStartToken: string;
  processGroupId?: number;
  controlEndpoint: string;
  modelManifestRef: string;
  eventJournalRef: string;
}
```

这些是建议接口，不是仓库当前可调用 API。不要把 credentials 放入 manifest。主与子角色允许不同模型/推理等级，校验的是其是否符合角色合同，而非是否全部相同。

所有 status 先确定 instance/进程出生身份，再报告 live observation 与 stored declaration 两个不同字段。过期文件不得覆盖现场观测。monitor 只有读取权限；其进程组与 runner 解耦，监控退出不能杀掉研究。

### R2：修正 watchdog 的时间语义

默认参数用虚拟时钟测试，不通过把 30 秒缩成 5 毫秒来替代。仅可信 pause/resume 控制事件可以扣除暂停时间；普通 event-loop 延迟不是用户暂停的证据。

区分以下观测：hostHeartbeatAt、providerEventAt、toolProgressAt、durableProgressAt。心跳证明包装器存活，不能证明科学进展。长计算或外部等待应记录 waitKind、operationId、预计下一次检查时间，不假装有进展，也不一律当卡死。

请求停止先关闭新工作入口，取消当前动作并对账，再形成 suspended 或 recovery-required；无法取消的外部操作保持 pending/unknown。

### R3：日志轮转与存储预算

分开管理活动日志段、已封存历史、全局磁盘使用与实际费用总账。旧封存日志不应因属于同一目录就耗尽新活动段额度；全局磁盘不足仍可触发安全暂停，不得取消真正的资源边界。

在接近容量阈值时先生成轻量 checkpoint，再封存段、切换新段。日志压缩/归档不能和关键执行共享失败命运。原始证据保存策略须由用户明确决定，不静默删日志。

读取增长文件采用打开 fd、固定 fstat 大小、限定起止偏移的 snapshot read；长行和截断 JSON 显式报告，不等待 EOF，不尾随写入。不要用另一个会无限读取的诊断工具解决日志过大。

### R4：锁恢复与合入对账

先区分锁拥有者存活、已死亡、身份未知。PID 复用、不同 host、owner 信息缺失或观察权限不够都不是自动删除依据。用 owner nonce/进程出生标识与竞争保护避免误接管；不能仅靠 TTL。

恢复前核对提案、已写版本、目标 snapshot、CURRENT 与 result：
- 没有发布：保留已写负面限制，依据冻结的 merge intent 继续或明确废弃未发布写入。
- 已发布且 snapshot 引用该 proposal：补齐回执，不重新分配知识 ID、不重复创建或修订。
- 无法确认：停留 recovery-required，不发起新的 M04 合入。

可在现有文件存储上增加小型 prepared/committed 回执，不必为此迁移整个数据库。旧 writer 必须失去提交资格后才允许新 writer 接管。原 limit 授权与撤回状态不随代码回退而撤销。

## 3. 核心状态修复：进程不是科研目标

使用正交状态而不是一个 finished 承担所有含义：

| 对象 | 状态示例 | 含义 |
|---|---|---|
| 科研目标 | open / fulfilled / withdrawn | 目标和成功要求是否仍有效 |
| 执行尝试 | running / waiting / quiescing / suspended / terminated | 这一进程或尝试怎样运行 |
| 科学判断 | supported / refuted / underdetermined | 对假设或结论的证据状态 |
| 外部动作 | prepared / issued / pending / confirmed / unknown | 真实副作用是否已发生 |
| 交接 | checkpoint-ready / evidence-incomplete / repair-required | 下一次能够继承哪些事实 |

宿主退出不等于科研目标失效。SIGTERM 不证明远端任务取消；timeout 不证明请求未发生。处理用户决策可以成为 waiting-user 的持久状态，不要求 print 模式维持一个永不退出的进程。

旧 blocked 目标不改写历史；受信恢复操作可以创建 successor attempt，并显式绑定原目标版本、原成功标准、知识限制与证据。新的 execution session 恢复显式状态，不扩大原会话权限，不自动重新提交未对账的外部动作。

### 最小 checkpoint

包括目标版本、成功条件、H/I/知识快照、角色映射、已评审任务、未决与用户授权、外部 operation IDs、实际参数和产物位置、最后 durable event 序号、下一步允许动作。

checkpoint 是控制器生成的小型恢复索引，不等于已读全部证据，也不等于科学结果已验证。无需完整 transcript 能装进一条提示词才允许恢复。M04 通过已有有界读取按需核对原证据。

## 4. 接回 RSI，而非扩张到另一个框架

### 4.1 三种运行模式

- serve：原科研路径使用固定、已接受 H/K；不触发改进调用。
- observe：只写轻量经验索引；观察组件失效不得改写科研终态。必要证据无法持久化时暂停相关有副作用工作，不能一概忽略 I/O 故障。
- evolve：独立工作区运行方法候选，持有总预算；不得直接写活动科研工作区、goal 或知识 CURRENT。

默认保持原科研路径。候选仅通过明确版本采用进入未来任务。正在运行的目标不热换 H/I/执行权限。

### 4.2 一条真正的科研方法适配器

当前 `research-service.ts` 仍要求 CPU executor；已有 M07 workflow prompt 槽位尚无对应完整提议—评价路径。保留 CPU 环境作为协议测试，不把其结果外推成一般科研收益。

第一条适配器建议采用真实 M07 的 research-check 或 evidence-handoff 槽位：
1. 固定原任务、K、模型与工具；运行当前 H 的真实基线。
2. 将实际执行/证据交接失败变成开发证据。
3. I 修改一个 H 槽位，不修改题目答案或验收规则。
4. 在独立副本执行 H 候选；真实检查结果进入 M04。
5. 独立准入后形成方法版本；未来新任务显式装载。

当前科研产物 A、生成产物的方法 H、改进 H 的机制 I 必须分别标记。修好了某道题的程序 A，不直接证明 H 或 I 得到改进。

### 4.3 H 快循环与 I 慢循环

H 循环用实际科研反馈改善执行方法。I 循环使用多个真实 MetaEpisode 改善诊断、候选构造或实验选择方式。一次只改变一个可归因的元机制。

不用再造 MetaEpisode、GenerationStore 或知识 epoch。新工作是让这些已存在对象真正参与下一轮，并允许 I 针对当前方法进行完整的研究过程。

notes 里的基础设施事故首先成为宿主回归测试；不能迫使提示词学习“绕过残锁”“偷用主 bash”来补偿底层错误。基础设施修复本轮属于人工工程修复，不标成 RSI 自主发现。

## 5. 反馈环境与经验积累

第一组真实任务至少包含数值复现、条件性证据交接和实验选择中的一种，优先使用现有可复算任务。既有已参与修复的题目归开发与回归，不重称盲测。

有效反馈需要连接：目标—动作—实际观察—检查—竞争性解释—下一干预。对科学负结果，必须区分“实验按协议完成但假设被证伪”和“实验根本没完成”。前者是有价值的研究结果，不是必须无限重试的工具失败。

完整档案保留失败、反例、未选分支、原材料和代码；活动知识包只给当前相关且适用的内容。知识采用继续走 C/K/E/J/Q/D/X 和 M04，不能由 improver 自评入库。

两种 checkpoint 不混淆：运行恢复 checkpoint 保存已有执行事实；知识 epoch 保存已按规定发布的 K。完成前者不自动完成后者。

## 6. 本轮固定的 L5 实验目标

### 结构

I0 依据真实改进过程生成 I1；I1 在规定验证后被保留；新的独立改进回合实际加载 I1；I1 控制后继 H 或 I 的生成/评价/选择。固定宿主与独立 G 不妨碍策略级 L5。

### 有效性

从相同 H0/K0、相同来源访问和可比总预算出发，分别运行 I0/I1 的完整搜索，冻结其所选终态，然后独立测后继。正常无赢家以 H0 作为终态；环境损坏、费用未知等基础设施失败单列，不能选择性排除不利运行。

先区分质量型与效率型目标。不要在看到结果后更换协议。分别重复完整搜索与后继执行；单位是独立任务/改进问题/campaign，不把相关的多次调用当作独立问题。

冻结 I1 在新任务族上继续做改进实验；通过 I0K0 / I0K1 / I1K0 / I1K1 消融区分经验增加与改进机制变化的作用。成本包含获得和验证 I1 的成本，另报告给定 I1 后的使用效率。

不要求每一轮晋级。必须能完整运行并正常拒绝无效候选。没有收益不能伪装成成功，运行中断也不能归因于模型科研能力。

## 7. 开发顺序与验收

| 批次 | 修改范围 | 退出条件 |
|---|---|---|
| A：现场隔离 | 稳定启动配置、独立 observer、保存现场 | 身份能唯一定位；停 observer 不停 runner；没有新增未授权请求 |
| B：控制恢复 | watchdog、日志生命周期、受控锁恢复/合入对账 | 默认时间测试与故障注入通过；保存负面限制 |
| C：原路径回归 | 真实 M07/M04、checkpoint 与恢复 | 无 RSI 模式完成原科研路径；外部动作不重复；已结束记录不篡改 |
| D：方法旁路 | 一个 M07 H 槽位适配器 | 真模型提出 H 并实际执行、检验、选择；允许无赢家 |
| E：元继承 | 既有 I pilot、meta-eval、代际入口 | 真 I1 在下一回合承担改进；有冻结起点的后继对照 |

每一批只合入能由对应回归用例验证的修复。先稳定一个 serial worker，再考虑并行吞吐；不要求先实现分布式调度、任意源码沙箱、所有学科、所有 L3/L4 产品能力。

## 8. 必须覆盖的回归用例

本包 regression-catalog.json 列出具体场景。关键项包括：
- 默认 30 秒 interval 的静默检测，不用毫秒参数替代。
- 长日志、旧历史与全局磁盘满分别触发不同处置。
- 监控超时/崩溃不杀 runner。
- 一个 wrapper PID 退出时能识别仍存活的子进程。
- owner 存活、死亡、PID 复用、权限未知、竞争接管。
- CURRENT 已发布但 result 未写的合入恢复只应用一次。
- API 已执行但响应丢失时先对账，不盲目重发。
- 合法 main-high/child-low 配置通过，非授权路由在调用前拒绝。
- 响应停止而科研目标仍 open，恢复用新 attempt 保持原要求。
- 负实验结果经 M04 处理，不制造 fulfilled 或无限重试。
- 未开启 RSI 时无额外改进请求；失败候选不污染活动科研运行。
- I1 真实重入，不以 fake runner 的固定答案冒充递归。

## 9. 研究来源与采纳边界

以下一手来源截至本次检索。方法启发与已证明结果分开。

- SoL-Pi：公开页报告长期编排代码膨胀导致实验启动负担，转向最小循环模板；其研究程序仍固定。借鉴小型稳定内核，不把丢弃实验编排理解为丢弃经验证的 H/I 或知识。
- Anthropic, Effective harnesses for long-running agents：初始化与增量工作、恢复时读取进度和先跑基本端到端检查。它不是科研 L5 的证明。
- ModularRSI：同题成功/失败对照、跨题模式、模块受限演进和独立集成检查。
- HarnessEvolve：参考轨迹辅助归因、检查泄漏与遗忘。用答案生成的参考轨迹只能在开发侧；最终验收仍独立。
- MetaSkill-Evolve / Hyperagents：可修改元机制、同一底座上快慢循环、后继生成能力验证。
- Rethinking Self-Evolving Agent Skills：进步稀疏且依赖反馈与任务，不应要求每轮成功。
- AIRA2：交互式研究、吞吐与评价噪声问题；当前不用先实现大规模异步集群。
- AWS Builders' Library, Making retries safe with idempotent APIs：外部操作超时不等于未发生；同一操作身份与服务端幂等/对账是安全重试的基础。对不支持幂等的服务不能宣称 exactly-once。

用户论文的定义依据：§2.2；§3.6，第31—35页；科学归因与实验产物/agent 区分：§4.1；复用与长期元评价：§6。其 L5 要求是继承并使用改进机制，能力收益还需独立、资源可比的后继评价。

## 10. 本轮交付约束

不把旧 notes 的测试题、分数、身份、路径和外部提交记录复制进本包。不提供能批量清锁、改终态或自动付费的修复脚本。复现代码无网络、无进程信号、无工作区写入，只有可选的结果文件输出。

最终验收目标：恢复一条原科研执行链；证明它能在本次记录的控制故障后安全交接；在不影响它的旁路里跑通 H/I 方法实验，并让真实新 I 控制后继回合。基础设施修复不能永久替代这条真实实验链。

## 补充：研究决策的开放程度

《Rethinking Self-Evolving Agents: Do We Still Need Prescribed Optimization Pipelines?》（arXiv:2608.09629）研究了在固定目标、交互权限、预算、数据边界与评价下，由优化模型在线组织改进过程的 Open-Ended Optimization。论文同时报告能力边界：中等优化器在其设置下由规定流程获得更好表现，较弱优化器不能操作相同开放接口。对本项目的建议不是撤销 P07/M04 或安全规则，而是将机械事务留给宿主，将诊断和实验选择交给可评测的 I；是否需要更多结构，应通过所用模型的真实 pilot 决定。

# 本包用途与验收状态

审查提交：a8facf5995d07da215bead2ce521088bd560e713。

- RECOVERY_AND_RSI_PLAN.md：恢复原科研执行路径，再闭合已有 H/I 方法研究的详细建议。
- regression-catalog.json：22 项待实现/待执行的项目验收规格，不是已通过测试。
- reproduce_control_rules.mjs：源码判断条件的隔离复现及拟议修复的虚拟时间对照。
- control-rule-results.json：上述脚本的实测输出，5 个用例通过。包括复现当前默认 watchdog 盲区、解释毫秒级测试覆盖不足、两个拟议逻辑对照，以及状态 PID 覆盖反例。
- sources-and-scope.json：来源与执行范围。

运行独立复现：

```bash
node reproduce_control_rules.mjs
```

本包不会自动安装或修复 Mul-Pis，不提供会杀进程或删除残锁的恢复脚本。没有调用真实模型、完整科研工作流、整仓集成测试或完成 RSI 实验。原 notes 中的题目、平台身份、提交数据、机器路径与原始会话未复制到本包。
